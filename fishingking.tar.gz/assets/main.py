"""FishingKing - 1994년 '낚시광'에서 영감을 받은 2D 민물/바다 낚시 게임.

PC: python main.py  /  웹(모바일): build_web.bat (pygbag)
"""
import asyncio

import pygame  # noqa: F401  (pygbag 은 main.py 의 import 를 보고 pygame 을 불러온다)

from game.app import App


async def main():
    await App().run()


asyncio.run(main())
