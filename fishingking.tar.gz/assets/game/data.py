"""어종, 낚시터, 상점 데이터."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Fish:
    id: str
    name: str
    min_len: float          # cm
    max_len: float          # cm
    weight_coef: float      # W(g) = coef * L^3
    base_price: int         # 평균 크기 기준 가격
    baits: dict             # 미끼별 선호도 {paste, worm, shrimp}
    mix: tuple              # 선호 떡밥 배합 (어분, 원자탄, 깻묵)
    size_pref: int          # 선호 떡밥 크기 0=소 1=중 2=대
    depth: str              # bottom / mid / top
    day: float              # 낮 활성도
    night: float            # 밤 활성도
    mouth: int              # 입 크기 1~3 (바늘 크기와 비교)
    strength: tuple         # 당기는 힘 kg (최소 크기, 최대 크기)
    stamina: float          # 체력 배율
    style: str              # rise(찌올림) / sink(찌잠김) / quick(깔짝 후 급하강)
    color: tuple
    belly: tuple
    shape: str = "normal"   # normal / long / flat / eel
    desc: str = ""
    sea: bool = False


SEA_MIX = (0.33, 0.33, 0.34)   # 바다 고기는 떡밥 배합과 무관

FISH = [
    Fish("pale_chub", "피라미", 8, 17, 0.011, 40,
         {"paste": 0.6, "worm": 1.2, "shrimp": 0.3}, (0.2, 0.6, 0.2), 0, "top", 1.2, 0.4, 1,
         (0.2, 0.5), 0.6, "quick", (120, 150, 170), (230, 210, 200), "normal",
         "여울에 무리지어 사는 작은 물고기. 입질이 빠르다."),
    Fish("crucian", "붕어", 12, 45, 0.022, 250,
         {"paste": 1.2, "worm": 1.0, "shrimp": 0.6}, (0.2, 0.5, 0.3), 1, "bottom", 1.0, 1.1, 2,
         (0.8, 3.0), 1.0, "rise", (120, 110, 60), (200, 190, 130), "flat",
         "민물낚시의 대표 어종. 찌를 천천히 올리는 입질이 일품."),
    Fish("gibel", "떡붕어", 15, 50, 0.021, 200,
         {"paste": 1.3, "worm": 0.4, "shrimp": 0.2}, (0.1, 0.4, 0.5), 1, "mid", 1.1, 0.8, 2,
         (1.0, 3.5), 1.0, "rise", (150, 150, 130), (215, 215, 200), "flat",
         "중층을 떠다니며 식물성 떡밥을 좋아한다."),
    Fish("carp", "잉어", 30, 100, 0.017, 900,
         {"paste": 1.2, "worm": 0.7, "shrimp": 0.5}, (0.3, 0.1, 0.6), 2, "bottom", 0.9, 1.2, 3,
         (2.5, 12.0), 1.6, "sink", (150, 120, 50), (220, 190, 110), "normal",
         "강의 터줏대감. 힘이 좋아 튼튼한 채비가 필요하다."),
    Fish("israeli_carp", "향어", 30, 80, 0.019, 700,
         {"paste": 1.3, "worm": 0.5, "shrimp": 0.4}, (0.6, 0.2, 0.2), 2, "bottom", 1.0, 1.0, 3,
         (2.5, 9.0), 1.4, "sink", (90, 100, 90), (190, 190, 170), "normal",
         "비늘이 거의 없는 잉어과. 어분 냄새에 약하다."),
    Fish("barbel", "누치", 20, 60, 0.012, 350,
         {"paste": 0.6, "worm": 1.2, "shrimp": 0.8}, (0.5, 0.3, 0.2), 1, "bottom", 1.0, 0.9, 2,
         (1.5, 5.0), 1.2, "sink", (170, 160, 140), (230, 225, 210), "long",
         "모래 바닥을 좋아하는 여울의 강자."),
    Fish("chub", "끄리", 15, 40, 0.012, 200,
         {"paste": 0.2, "worm": 1.0, "shrimp": 1.2}, (0.4, 0.4, 0.2), 1, "top", 1.2, 0.5, 2,
         (0.8, 2.5), 0.9, "quick", (90, 120, 150), (220, 220, 230), "long",
         "작은 물고기를 사냥하는 육식성. 새우에 잘 문다."),
    Fish("bagrid", "동자개", 10, 30, 0.012, 250,
         {"paste": 0.5, "worm": 1.4, "shrimp": 1.0}, (0.8, 0.1, 0.1), 0, "bottom", 0.4, 1.5, 2,
         (0.5, 1.5), 0.9, "sink", (170, 140, 40), (230, 210, 120), "long",
         "'빠가사리'. 밤에 활발하며 가시를 조심할 것."),
    Fish("catfish", "메기", 30, 100, 0.008, 1000,
         {"paste": 0.4, "worm": 1.3, "shrimp": 1.0}, (0.9, 0.05, 0.05), 2, "bottom", 0.3, 1.6, 3,
         (3.0, 10.0), 1.5, "sink", (70, 70, 60), (180, 175, 160), "long",
         "밤의 사냥꾼. 어분과 지렁이를 좋아한다."),
    Fish("snakehead", "가물치", 40, 90, 0.009, 1500,
         {"paste": 0.1, "worm": 0.6, "shrimp": 1.0}, (0.5, 0.3, 0.2), 2, "top", 1.2, 0.8, 3,
         (4.0, 13.0), 1.7, "sink", (60, 70, 50), (170, 170, 140), "long",
         "수초밭의 폭군. 수면 가까이 미끼를 노린다."),
    Fish("eel", "뱀장어", 40, 100, 0.0015, 2500,
         {"paste": 0.2, "worm": 1.4, "shrimp": 0.9}, (0.8, 0.1, 0.1), 1, "bottom", 0.2, 1.6, 2,
         (2.0, 6.0), 1.6, "sink", (60, 70, 50), (200, 200, 150), "eel",
         "귀한 야행성 어종. 깊은 바닥에서 지렁이를 노린다."),
    Fish("mandarin", "쏘가리", 20, 50, 0.016, 3000,
         {"paste": 0.1, "worm": 0.9, "shrimp": 1.5}, (0.5, 0.3, 0.2), 1, "bottom", 0.8, 1.2, 3,
         (1.5, 5.0), 1.3, "quick", (170, 140, 60), (230, 210, 150), "normal",
         "'민물의 왕자'. 여울 바위틈에 숨어 산다."),
    Fish("golden_carp", "황금잉어", 70, 120, 0.018, 30000,
         {"paste": 1.0, "worm": 0.5, "shrimp": 0.4}, (0.3, 0.1, 0.6), 2, "bottom", 0.7, 1.3, 3,
         (6.0, 16.0), 2.0, "sink", (240, 180, 30), (255, 230, 120), "normal",
         "전설로만 전해지는 황금빛 잉어. 과연 실존할까?"),
    # ---------------------------------------------------------- 댐 / 저수지
    Fish("bass", "배스", 20, 60, 0.016, 400,
         {"paste": 0.05, "worm": 1.0, "shrimp": 1.3}, (0.5, 0.3, 0.2), 1, "mid", 1.2, 0.6, 3,
         (1.5, 5.5), 1.3, "sink", (90, 120, 60), (220, 220, 180), "normal",
         "공격적인 외래어종. 새우를 덮치듯 문다."),
    Fish("bluegill", "블루길", 8, 25, 0.03, 50,
         {"paste": 0.8, "worm": 1.3, "shrimp": 0.8}, (0.4, 0.4, 0.2), 0, "mid", 1.2, 0.5, 1,
         (0.3, 0.8), 0.7, "quick", (70, 100, 110), (230, 180, 90), "flat",
         "작은 외래어종. 어디서든 잘 달려든다."),
    Fish("skygager", "강준치", 30, 100, 0.006, 600,
         {"paste": 0.3, "worm": 0.8, "shrimp": 1.2}, (0.5, 0.3, 0.2), 1, "top", 1.1, 0.7, 3,
         (2.0, 8.0), 1.3, "quick", (160, 170, 180), (235, 235, 240), "long",
         "댐에 사는 은빛 대형 육식어. 수면 가까이서 사냥한다."),
    # ---------------------------------------------------------- 바다
    Fish("goby", "망둥어", 8, 25, 0.012, 50,
         {"krill": 0.6, "clamworm": 1.4, "shrimp": 0.8, "squid": 0.3}, SEA_MIX, 1, "bottom", 1.2, 0.6, 1,
         (0.2, 0.6), 0.6, "quick", (150, 140, 110), (220, 210, 180), "long",
         "방파제의 단골손님. 아무 미끼나 덥석 문다.", True),
    Fish("greenling", "노래미", 15, 45, 0.013, 300,
         {"krill": 0.8, "clamworm": 1.3, "shrimp": 1.0, "squid": 0.6}, SEA_MIX, 1, "bottom", 1.1, 0.8, 2,
         (0.8, 2.5), 1.0, "sink", (120, 100, 60), (210, 190, 140), "long",
         "바위 틈에 사는 갈색 물고기. 갯지렁이를 좋아한다.", True),
    Fish("rockfish", "우럭", 15, 55, 0.02, 600,
         {"krill": 0.8, "clamworm": 1.0, "shrimp": 1.2, "squid": 1.0}, SEA_MIX, 1, "bottom", 0.9, 1.3, 3,
         (1.0, 4.5), 1.1, "sink", (80, 80, 75), (170, 165, 150), "normal",
         "'조피볼락'. 큰 입으로 바닥의 미끼를 삼킨다.", True),
    Fish("rockfish_b", "볼락", 10, 30, 0.018, 500,
         {"krill": 1.2, "clamworm": 1.0, "shrimp": 1.2, "squid": 0.4}, SEA_MIX, 1, "mid", 0.5, 1.6, 2,
         (0.4, 1.2), 0.8, "quick", (120, 90, 70), (200, 170, 140), "normal",
         "밤이면 떠오르는 볼락. 크릴 밤낚시의 인기 어종.", True),
    Fish("horse_mackerel", "전갱이", 15, 40, 0.011, 200,
         {"krill": 1.4, "clamworm": 0.5, "shrimp": 0.8, "squid": 0.4}, SEA_MIX, 1, "mid", 1.0, 1.2, 2,
         (0.6, 2.0), 0.8, "quick", (110, 140, 150), (225, 230, 225), "normal",
         "떼로 몰려다니는 등푸른 생선. 크릴에 잘 문다.", True),
    Fish("mackerel", "고등어", 20, 45, 0.01, 300,
         {"krill": 1.3, "clamworm": 0.4, "shrimp": 0.8, "squid": 0.8}, SEA_MIX, 1, "top", 1.2, 0.6, 2,
         (1.0, 3.0), 1.0, "quick", (50, 110, 120), (235, 235, 230), "normal",
         "힘 좋은 등푸른 생선. 한번 붙으면 줄줄이 문다.", True),
    Fish("mullet", "숭어", 30, 80, 0.011, 400,
         {"krill": 1.0, "clamworm": 0.8, "shrimp": 0.6, "squid": 0.2}, SEA_MIX, 1, "top", 1.2, 0.7, 2,
         (2.0, 6.0), 1.2, "sink", (110, 120, 130), (225, 225, 225), "long",
         "펄쩍펄쩍 뛰어오르는 숭어. 점프에 주의!", True),
    Fish("black_porgy", "감성돔", 20, 60, 0.022, 2500,
         {"krill": 1.3, "clamworm": 0.8, "shrimp": 1.2, "squid": 0.3}, SEA_MIX, 1, "bottom", 1.0, 1.0, 3,
         (1.5, 6.0), 1.3, "sink", (70, 75, 80), (170, 175, 180), "flat",
         "바다 찌낚시의 꽃. 찌를 쏙 끌고 들어간다.", True),
    Fish("sea_bass", "농어", 30, 100, 0.01, 2000,
         {"krill": 0.4, "clamworm": 0.6, "shrimp": 1.4, "squid": 0.8}, SEA_MIX, 1, "top", 0.8, 1.3, 3,
         (3.0, 10.0), 1.5, "sink", (120, 130, 130), (230, 230, 230), "long",
         "바늘털이의 명수. 수면 위로 솟구쳐 머리를 흔든다.", True),
    Fish("flounder", "광어", 30, 90, 0.013, 2200,
         {"krill": 0.2, "clamworm": 0.6, "shrimp": 1.2, "squid": 1.0}, SEA_MIX, 1, "bottom", 1.0, 1.0, 3,
         (2.5, 9.0), 1.4, "sink", (110, 95, 60), (240, 235, 220), "flat",
         "'넙치'. 바닥에 납작 엎드려 있다 미끼를 덮친다.", True),
    Fish("red_seabream", "참돔", 30, 90, 0.02, 4000,
         {"krill": 1.2, "clamworm": 0.6, "shrimp": 1.2, "squid": 0.8}, SEA_MIX, 1, "bottom", 1.0, 0.9, 3,
         (3.0, 11.0), 1.6, "sink", (220, 110, 110), (250, 200, 190), "flat",
         "바다의 여왕. 붉은 몸빛이 아름답다.", True),
    Fish("hairtail", "갈치", 60, 130, 0.0012, 1500,
         {"krill": 0.2, "clamworm": 0.3, "shrimp": 0.6, "squid": 1.4}, SEA_MIX, 1, "mid", 0.2, 1.8, 3,
         (1.5, 4.0), 1.0, "quick", (200, 210, 220), (240, 245, 250), "eel",
         "은빛 칼 같은 물고기. 밤바다 선상낚시의 주인공.", True),
    Fish("yellowtail", "방어", 50, 100, 0.013, 6000,
         {"krill": 0.4, "clamworm": 0.2, "shrimp": 1.0, "squid": 1.2}, SEA_MIX, 1, "mid", 1.2, 0.6, 4,
         (6.0, 18.0), 2.2, "sink", (70, 100, 140), (230, 230, 220), "normal",
         "무시무시한 힘의 회유어. 특대 바늘과 굵은 줄 필수.", True),
    Fish("beakfish", "돌돔", 25, 60, 0.025, 8000,
         {"krill": 0.2, "clamworm": 0.6, "shrimp": 0.8, "squid": 0.8}, SEA_MIX, 1, "bottom", 1.1, 0.6, 3,
         (4.0, 12.0), 2.0, "sink", (60, 60, 60), (200, 200, 190), "flat",
         "갯바위의 제왕. 체구에 비해 엄청난 힘을 낸다.", True),
    Fish("bluefin", "참다랑어", 100, 200, 0.02, 50000,
         {"krill": 0.1, "clamworm": 0.1, "shrimp": 0.8, "squid": 1.2}, SEA_MIX, 1, "mid", 1.0, 0.8, 4,
         (15.0, 28.0), 2.5, "sink", (30, 50, 110), (210, 215, 225), "normal",
         "바다의 전설. 이 녀석을 낚으면 진정한 바다의 왕.", True),
]
FISH_BY_ID = {f.id: f for f in FISH}


@dataclass(frozen=True)
class Spot:
    key: str
    name: str
    desc: str
    bottom: float           # 수심 m
    hot: float              # 고기가 모이는 거리 m
    population: dict        # fish_id -> 개체수 가중치
    water: tuple            # 수면 색 (낮)
    feature: str            # 배경 연출
    region: str = "river"   # river / lake / sea
    sea: bool = False
    style: str = "float"    # float(찌낚시) / tip(선상 초릿대 입질)
    size_bonus: float = 0.0  # 큰 고기가 잘 나오는 정도
    fee: int = 0            # 들어갈 때마다 내는 요금 (배삯)


SPOTS = [
    Spot("A", "A. 여울목", "물살이 빠른 얕은 여울. 작은 고기와 쏘가리가 산다.",
         1.2, 8.0,
         {"pale_chub": 3.0, "chub": 1.5, "barbel": 1.2, "mandarin": 0.15, "bagrid": 0.5, "crucian": 0.3},
         (70, 140, 150), "rapids"),
    Spot("B", "B. 수초밭", "연잎과 수초가 우거진 곳. 붕어의 천국.",
         1.8, 10.0,
         {"crucian": 3.0, "gibel": 1.5, "snakehead": 0.35, "pale_chub": 0.6, "carp": 0.4},
         (60, 120, 80), "weeds"),
    Spot("C", "C. 깊은 소", "강이 굽이치며 생긴 깊은 웅덩이. 대물의 은신처.",
         4.0, 17.0,
         {"carp": 1.5, "israeli_carp": 1.2, "catfish": 0.8, "eel": 0.15, "gibel": 0.8,
          "barbel": 0.6, "golden_carp": 0.05},
         (30, 80, 90), "deep"),
    Spot("D", "D. 갈대 연안", "갈대가 늘어선 완만한 물가. 밤낚시 명당.",
         2.5, 12.0,
         {"crucian": 2.0, "carp": 0.8, "bagrid": 1.2, "catfish": 0.5, "eel": 0.12, "gibel": 0.8,
          "golden_carp": 0.025},
         (70, 110, 100), "reeds"),
    Spot("E", "E. 댐", "깊고 넓은 댐 호수. 쏘가리와 강준치, 배스의 무대.",
         7.0, 18.0,
         {"bass": 1.5, "skygager": 1.2, "mandarin": 0.5, "carp": 1.0, "israeli_carp": 0.8,
          "catfish": 0.6, "barbel": 0.8, "golden_carp": 0.04},
         (30, 70, 100), "dam", region="lake", size_bonus=0.3),
    Spot("F", "F. 저수지", "마을 옆 오래된 저수지. 월척 붕어가 산다는 소문.",
         2.2, 11.0,
         {"crucian": 3.0, "gibel": 1.2, "bluegill": 1.5, "bass": 0.8, "snakehead": 0.5,
          "carp": 0.6, "catfish": 0.4, "bagrid": 0.5},
         (70, 110, 70), "reservoir", region="lake", size_bonus=0.6),
    Spot("G", "G. 방파제", "항구의 방파제. 바다낚시 입문자의 놀이터.",
         6.0, 15.0,
         {"goby": 2.0, "greenling": 1.2, "rockfish": 0.8, "rockfish_b": 1.0, "horse_mackerel": 1.5,
          "mackerel": 1.2, "mullet": 0.8, "black_porgy": 0.25, "sea_bass": 0.2},
         (40, 110, 160), "breakwater", region="sea", sea=True),
    Spot("H", "H. 갯바위", "파도가 부서지는 갯바위. 감성돔과 돌돔을 노린다.",
         9.0, 20.0,
         {"black_porgy": 1.0, "red_seabream": 0.4, "rockfish": 1.0, "greenling": 0.8, "rockfish_b": 1.0,
          "sea_bass": 0.5, "beakfish": 0.12, "mullet": 0.4},
         (30, 90, 150), "rocks", region="sea", sea=True, size_bonus=0.2),
    Spot("I", "I. 선상낚시", "배를 타고 먼바다로! 초릿대 입질을 보고 챔질한다.",
         30.0, 0.0,
         {"rockfish": 1.5, "flounder": 0.8, "red_seabream": 0.8, "yellowtail": 0.4, "hairtail": 1.0,
          "mackerel": 0.8, "greenling": 0.4, "bluefin": 0.02},
         (20, 70, 140), "boat", region="sea", sea=True, style="tip", size_bonus=0.3, fee=2000),
]
SPOT_BY_KEY = {s.key: s for s in SPOTS}

REGIONS = [
    {"id": "river", "name": "강", "price": 0},
    {"id": "lake", "name": "댐·저수지", "price": 5000},
    {"id": "sea", "name": "바다", "price": 15000},
]
REGION_BY_ID = {r["id"]: r for r in REGIONS}

FRESH_BAITS = ["paste", "worm", "shrimp"]
SEA_BAITS = ["krill", "clamworm", "shrimp", "squid"]
CHUM_BAITS = ("paste", "krill")     # 던질수록 고기를 모으고, 시간이 지나면 풀리는 미끼
BAIT_NAMES = {"paste": "떡밥", "worm": "지렁이", "shrimp": "새우",
              "krill": "크릴", "clamworm": "갯지렁이", "squid": "오징어살"}
BAIT_DESC = {
    "worm": "지렁이: 거의 모든 고기가 좋아하는 동물성 미끼.\n밤낚시의 메기, 동자개, 뱀장어에 특효.",
    "shrimp": "새우: 육식성 고기를 부르는 미끼.\n쏘가리, 배스, 농어, 광어가 좋아한다.",
    "krill": "크릴: 바다 찌낚시의 기본 미끼.\n같은 곳에 던질수록 밑밥이 쌓여 고기가 모인다.",
    "clamworm": "갯지렁이: 바닥 고기에게 인기 만점.\n망둥어, 노래미, 우럭이 좋아한다.",
    "squid": "오징어살: 질겨서 잘 떨어지지 않는 미끼.\n갈치, 방어, 참다랑어 같은 대물용.",
}
PASTE_SIZE_NAMES = ["소", "중", "대"]
MIX_NAMES = ["어분", "원자탄", "깻묵"]

# ---------------------------------------------------------------- 상점
RODS = [
    {"id": "rod0", "name": "대나무 낚싯대", "price": 0, "absorb": 1.00, "cast": 13, "desc": "할아버지께 물려받은 낚싯대"},
    {"id": "rod1", "name": "글라스 낚싯대", "price": 2500, "absorb": 0.88, "cast": 16, "desc": "충격 흡수 +12%, 최대 16m"},
    {"id": "rod2", "name": "카본 낚싯대", "price": 9000, "absorb": 0.76, "cast": 19, "desc": "충격 흡수 +24%, 최대 19m"},
    {"id": "rod3", "name": "명인의 낚싯대", "price": 30000, "absorb": 0.64, "cast": 23, "desc": "충격 흡수 +36%, 최대 23m"},
    {"id": "rod4", "name": "바다 원투대", "price": 18000, "absorb": 0.72, "cast": 32, "desc": "충격 흡수 +28%, 최대 32m (멀리 던지기)"},
    {"id": "rod5", "name": "선상 대물대", "price": 60000, "absorb": 0.50, "cast": 18, "desc": "충격 흡수 +50%, 최대 18m (대물 전용)"},
]
LINES = [
    {"id": "line0", "name": "1.5호 원줄", "price": 0, "strength": 3.0, "shy": 1.00, "desc": "버티는 힘 3.0kg"},
    {"id": "line1", "name": "2호 원줄", "price": 1200, "strength": 4.5, "shy": 0.96, "desc": "버티는 힘 4.5kg"},
    {"id": "line2", "name": "3호 원줄", "price": 4000, "strength": 6.5, "shy": 0.92, "desc": "버티는 힘 6.5kg (고기가 약간 경계)"},
    {"id": "line3", "name": "4호 원줄", "price": 10000, "strength": 9.0, "shy": 0.87, "desc": "버티는 힘 9.0kg (고기가 경계)"},
    {"id": "line4", "name": "6호 원줄", "price": 25000, "strength": 13.0, "shy": 0.80, "desc": "버티는 힘 13kg (고기가 많이 경계)"},
    {"id": "line5", "name": "8호 원줄", "price": 40000, "strength": 18.0, "shy": 0.75, "desc": "버티는 힘 18kg (바다 대물용)"},
    {"id": "line6", "name": "12호 합사", "price": 80000, "strength": 26.0, "shy": 0.70, "desc": "버티는 힘 26kg (참다랑어도 버틴다)"},
]
HOOKS = [
    {"id": "hook1", "name": "소 바늘", "price": 400, "size": 1, "desc": "작은 고기용"},
    {"id": "hook2", "name": "중 바늘", "price": 0, "size": 2, "desc": "붕어 크기에 알맞다"},
    {"id": "hook3", "name": "대 바늘", "price": 1200, "size": 3, "desc": "대물용. 작은 고기는 잘 안 걸린다"},
    {"id": "hook4", "name": "특대 바늘", "price": 3000, "size": 4, "desc": "방어, 참다랑어 같은 바다 대물용"},
]
TOOLS = [
    {"id": "net", "name": "뜰채", "price": 3000, "desc": "45cm 넘는 고기를 안전하게 건진다"},
    {"id": "lantern", "name": "캐미라이트", "price": 1500, "desc": "밤에 찌가 잘 보이고 챔질 타이밍이 넉넉해진다"},
]
CONSUMABLES = [
    {"id": "paste", "name": "떡밥 재료 10회분", "price": 300, "amount": 10},
    {"id": "worm", "name": "지렁이 10마리", "price": 200, "amount": 10},
    {"id": "shrimp", "name": "새우 10마리", "price": 500, "amount": 10},
    {"id": "krill", "name": "크릴 10회분", "price": 400, "amount": 10},
    {"id": "clamworm", "name": "갯지렁이 10마리", "price": 500, "amount": 10},
    {"id": "squid", "name": "오징어살 10개", "price": 700, "amount": 10},
]


def find_item(items, item_id):
    for it in items:
        if it["id"] == item_id:
            return it
    return items[0]
