"""전역 설정과 상수."""
import os
import sys

IS_WEB = sys.platform == "emscripten"   # pygbag(브라우저) 에서 실행 중
MOBILE = IS_WEB or bool(os.environ.get("FK_MOBILE"))   # 폰 화면용 큰 글씨 (FK_MOBILE=1 로 PC 에서 미리보기)
FONT_SCALE = 1.2 if MOBILE else 1.0

TITLE = "FishingKing"
VERSION = "1.2.0"
SCREEN_W, SCREEN_H = 1280, 600      # 와이드 (요즘 폰 가로 비율에 맞춤)
FPS = 60

# 하단 메뉴바
MENU_H = 60
PLAY_H = SCREEN_H - MENU_H

# 원근: 수면이 시작되는 y, 가장 가까운 수면 y
HORIZON_Y = 240
NEAR_Y = 490

# 예전 960 폭 기준으로 그린 좌표를 가운데 정렬할 때 더하는 값
CX = SCREEN_W // 2
DX = CX - 480


def resource_path(*parts):
    """PyInstaller onefile 에서도 동작하는 리소스 경로."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, *parts)


def save_dir():
    if IS_WEB:
        return "."
    root = os.environ.get("APPDATA") or os.path.expanduser("~")
    path = os.path.join(root, "FishingKing")
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        return "."
    return path


SAVE_FILE = os.path.join(save_dir(), "save.json")

FONT_CANDIDATES = [
    resource_path("assets", "fonts", "game.ttf"),       # 게임에 포함된 나눔고딕 (웹/모바일 공통)
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\malgunbd.ttf",
    r"C:\Windows\Fonts\gulim.ttc",
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
    "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
]
FONT_BOLD_CANDIDATES = [resource_path("assets", "fonts", "game_bold.ttf"), r"C:\Windows\Fonts\malgunbd.ttf"] + FONT_CANDIDATES

# 색상
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
WOOD = (214, 184, 112)
WOOD_LIGHT = (232, 208, 146)
WOOD_DARK = (150, 118, 58)
WOOD_TEXT = (72, 48, 18)
WOOD_DISABLED = (170, 150, 110)
RED = (210, 50, 40)
GREEN = (60, 170, 70)
YELLOW = (240, 200, 40)
GOLD = (255, 205, 60)
SKY_DAY_TOP = (120, 180, 235)
SKY_DAY_BOTTOM = (200, 230, 250)
SKY_NIGHT_TOP = (8, 12, 36)
SKY_NIGHT_BOTTOM = (34, 44, 88)
