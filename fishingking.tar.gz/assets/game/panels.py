"""낚시 화면 위에 뜨는 나무판 패널들."""
import math

import pygame

from . import gfx
from .data import (BAIT_DESC, BAIT_NAMES, CONSUMABLES, FISH, FISH_BY_ID, FRESH_BAITS, HOOKS, LINES, MIX_NAMES,
                   PASTE_SIZE_NAMES, REGION_BY_ID, RODS, SEA_BAITS, SPOTS, TOOLS, find_item)
from .settings import GOLD, IS_WEB, PLAY_H, RED, SCREEN_W, WOOD_LIGHT, WOOD_TEXT
from .ui import Button, Slider, text, wood_panel, wrap_text


class Panel:
    title = ""
    size = (560, 420)

    def __init__(self, scene):
        self.scene = scene
        self.app = scene.app
        self.save = scene.app.save
        self.sounds = scene.app.sounds
        w, h = self.size
        self.rect = pygame.Rect((SCREEN_W - w) // 2, (PLAY_H - h) // 2, w, h)
        self.widgets = []
        self.closed = False
        self.build()

    def build(self):
        pass

    def rebuild(self):
        self.widgets = []
        self.build()

    def close(self):
        self.closed = True
        self.save.save()
        self.on_close()

    def on_close(self):
        pass

    def close_button(self, label="닫기"):
        r = self.rect
        self.widgets.append(Button((r.right - 110, r.bottom - 52, 96, 40), label, self.close, 18))

    def handle(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.close()
            return True
        for w in list(self.widgets):
            if w.handle(event, self.sounds):
                return True
        return event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP)

    def draw_frame(self, surface):
        wood_panel(surface, self.rect)
        if self.title:
            bar = pygame.Rect(self.rect.left + 20, self.rect.top + 12, self.rect.w - 40, 38)
            wood_panel(surface, bar, WOOD_LIGHT, screws=False, border=2)
            text(surface, self.title, bar.center, 22, bold=True, center=True)

    def draw(self, surface):
        self.draw_frame(surface)
        self.draw_content(surface)
        for w in self.widgets:
            w.draw(surface)

    def draw_content(self, surface):
        pass

    def update(self, dt):
        pass


# ------------------------------------------------------------------ 음향
class SoundPanel(Panel):
    title = "음향"
    size = (420, 300)

    def build(self):
        r = self.rect
        snd = self.save["sound"]
        self.widgets.append(Button((r.left + 40, r.top + 70, 160, 44), f"효과음 {'켜짐' if snd['sfx'] else '꺼짐'}",
                                   lambda: self.toggle("sfx"), 18, toggled=snd["sfx"]))
        self.widgets.append(Button((r.left + 220, r.top + 70, 160, 44), f"환경음 {'켜짐' if snd['ambient'] else '꺼짐'}",
                                   lambda: self.toggle("ambient"), 18, toggled=snd["ambient"]))
        self.widgets.append(Slider((r.left + 70, r.top + 140, 280, 54), "음량", round(snd["volume"] * 10), 0, 10, 1,
                                   self.set_volume))
        if IS_WEB:
            self.widgets.append(Button((r.left + 24, r.bottom - 52, 140, 40), "전체 화면", self.app.request_fullscreen, 17))
        self.close_button()

    def toggle(self, key):
        self.save["sound"][key] = not self.save["sound"][key]
        self.rebuild()

    def set_volume(self, v):
        self.save["sound"]["volume"] = v / 10


# ------------------------------------------------------------------ 조정 (찌 높이 + 장비 장착)
class AdjustPanel(Panel):
    title = "채비 조정"
    size = (600, 470)

    def build(self):
        r = self.rect
        spot = self.scene.spot
        vmax = max(5.0, spot.bottom + 1.0) if spot.style == "float" else spot.bottom
        step = 0.1 if vmax <= 10 else 0.5
        label = "찌 높이" if spot.style == "float" else "채비 수심"
        self.widgets.append(Slider((r.left + 40, r.top + 70, 300, 54), label, self.save.depth_for(spot),
                                   0.2 if step < 0.5 else 0.5, vmax, step, self.set_depth, "{:.1f}m"))
        y = r.top + 200
        for key, items, label in (("rod", RODS, "낚싯대"), ("line", LINES, "원줄"), ("hook", HOOKS, "바늘")):
            owned = [it for it in items if self.save.owns(it["id"])]
            self.widgets.append(Button((r.left + 150, y, 40, 40), "◀", lambda k=key, it=owned: self.cycle(k, it, -1), 18,
                                       enabled=len(owned) > 1))
            self.widgets.append(Button((r.left + 470, y, 40, 40), "▶", lambda k=key, it=owned: self.cycle(k, it, 1), 18,
                                       enabled=len(owned) > 1))
            y += 58
        self.close_button()

    def set_depth(self, v):
        self.save.set_depth(self.scene.spot, v)

    def cycle(self, key, owned, step):
        ids = [it["id"] for it in owned]
        cur = ids.index(self.save[key]) if self.save[key] in ids else 0
        self.save[key] = ids[(cur + step) % len(ids)]

    def draw_content(self, surface):
        r = self.rect
        spot = self.scene.spot
        text(surface, f"이곳 수심: {spot.bottom:.1f}m", (r.left + 370, r.top + 76), 18, bold=True)
        depth = self.save.depth_for(spot)
        lying = spot.style == "float" and depth > spot.bottom + 0.3
        if lying:
            text(surface, "찌가 누울 거예요!", (r.left + 370, r.top + 102), 17, RED, bold=True)
        else:
            gap = spot.bottom - depth
            where = "바닥" if gap <= 0.15 + 0.03 * spot.bottom else ("중층" if gap < spot.bottom * 0.6 else "상층")
            text(surface, f"미끼 위치: {where}", (r.left + 370, r.top + 102), 17)
        if spot.style == "tip":
            tip = "선상낚시는 찌 없이 채비를 내립니다. 수심에 맞추면 바닥층, 얕게 하면 중·상층 고기를 노립니다."
        else:
            tip = "찌 높이를 수심에 맞추면 바닥층, 얕게 하면 중·상층 고기를 노립니다."
        for i, line in enumerate(wrap_text(tip, 15, r.w - 80)):
            text(surface, line, (r.left + 40, r.top + 140 + i * 20), 15)
        y = r.top + 200
        for key, items, label in (("rod", RODS, "낚싯대"), ("line", LINES, "원줄"), ("hook", HOOKS, "바늘")):
            item = find_item(items, self.save[key])
            text(surface, label, (r.left + 40, y + 9), 19, bold=True)
            box = pygame.Rect(r.left + 196, y, 268, 40)
            pygame.draw.rect(surface, (245, 230, 180), box, border_radius=4)
            pygame.draw.rect(surface, (150, 118, 58), box, 2, border_radius=4)
            text(surface, item["name"], (box.centerx, box.top + 12), 17, bold=True, center=True)
            text(surface, item["desc"], (box.centerx, box.top + 30), 12, center=True)
            y += 58
        extras = [t["name"] for t in TOOLS if self.save.owns(t["id"])]
        text(surface, "도구: " + (", ".join(extras) if extras else "없음"), (r.left + 40, r.bottom - 44), 16)


# ------------------------------------------------------------------ 먹이 (원작 스타일)
class BaitPanel(Panel):
    title = "먹이"
    size = (620, 440)

    def build(self):
        r = self.rect
        stock = self.save["stock"]
        spot = self.scene.spot
        if self.bait not in self.baits():
            self.save.set_bait(spot, self.baits()[0])
        y = r.top + 70
        for key in self.baits():
            self.widgets.append(Button((r.left + 30, y, 170, 50), f"{BAIT_NAMES[key]} ({stock[key]})",
                                       lambda k=key: self.set_bait(k), 19, toggled=self.bait == key))
            y += 62
        if self.bait == "paste":
            for i in range(3):
                self.widgets.append(Button((r.left + 240, r.top + 100 + i * 78, 110, 68), "",
                                           lambda i=i: self.set_size(i), 16, toggled=self.save["paste_size"] == i))
            for i in range(3):
                self.widgets.append(Slider((r.left + 390, r.top + 92 + i * 80, 200, 54), MIX_NAMES[i],
                                           self.save["mix"][i], 0, 10, 1, lambda v, i=i: self.set_mix(i, v)))
        self.close_button()

    @property
    def bait(self):
        return self.save.bait_for(self.scene.spot)

    def baits(self):
        return SEA_BAITS if self.scene.spot.sea else FRESH_BAITS

    def set_bait(self, key):
        self.save.set_bait(self.scene.spot, key)
        self.rebuild()

    def set_size(self, i):
        self.save["paste_size"] = i
        self.rebuild()

    def set_mix(self, i, v):
        self.save["mix"][i] = int(v)

    def draw_content(self, surface):
        r = self.rect
        if self.bait == "paste":
            text(surface, "크기", (r.left + 295, r.top + 74), 19, bold=True, center=True)
            text(surface, "배합", (r.left + 490, r.top + 66), 19, bold=True, center=True)
        else:
            for i, line in enumerate(BAIT_DESC[self.bait].split("\n")):
                for j, part in enumerate(wrap_text(line, 17, r.w - 260)):
                    text(surface, part, (r.left + 230, r.top + 110 + i * 52 + j * 24), 17)
        mix = self.save["mix"]
        total = sum(mix)
        if self.bait == "paste":
            if total:
                pct = " / ".join(f"{MIX_NAMES[i]} {mix[i] * 100 // total}%" for i in range(3))
            else:
                pct = "재료를 넣어주세요!"
            text(surface, pct, (r.left + 30, r.bottom - 44), 16, RED if not total else WOOD_TEXT, bold=True)

    def draw(self, surface):
        super().draw(surface)
        if self.bait == "paste":
            for i in range(3):
                c = (self.rect.left + 280, self.rect.top + 134 + i * 78)
                rad = 8 + i * 6
                pygame.draw.circle(surface, (110, 90, 40), c, rad)
                pygame.draw.circle(surface, (150, 125, 60), (c[0] - rad // 3, c[1] - rad // 3), rad // 2)
                text(surface, PASTE_SIZE_NAMES[i], (c[0] + 44, c[1]), 18, bold=True, center=True)


# ------------------------------------------------------------------ 상점
class ShopPanel(Panel):
    title = "낚시방"
    size = (760, 600)
    TABS = [("rod", "낚싯대"), ("line", "원줄"), ("hook", "바늘·도구"), ("bait", "미끼")]

    def __init__(self, scene):
        self.tab = "rod"
        self.flash = ""
        self.flash_t = 0.0
        super().__init__(scene)

    def build(self):
        r = self.rect
        for i, (key, label) in enumerate(self.TABS):
            self.widgets.append(Button((r.left + 24 + i * 130, r.top + 60, 122, 40), label,
                                       lambda k=key: self.set_tab(k), 18, toggled=self.tab == key))
        y = r.top + 116
        for item, kind in self.items():
            price = item["price"]
            if kind == "consumable":
                self.widgets.append(Button((r.right - 250, y + 5, 104, 40), f"{price}원",
                                           lambda it=item: self.buy_consumable(it, 1), 16,
                                           enabled=self.save["money"] >= price))
                self.widgets.append(Button((r.right - 138, y + 5, 104, 40), f"x5 {price * 5}원",
                                           lambda it=item: self.buy_consumable(it, 5), 15,
                                           enabled=self.save["money"] >= price * 5))
            else:
                owned = self.save.owns(item["id"])
                equipped = kind in ("rod", "line", "hook") and self.save[kind] == item["id"]
                if equipped:
                    self.widgets.append(Button((r.right - 170, y + 5, 136, 40), "장착중", None, 16, enabled=False))
                elif owned and kind in ("rod", "line", "hook"):
                    self.widgets.append(Button((r.right - 170, y + 5, 136, 40), "장착",
                                               lambda it=item, k=kind: self.equip(k, it), 16))
                elif owned:
                    self.widgets.append(Button((r.right - 170, y + 5, 136, 40), "보유중", None, 16, enabled=False))
                else:
                    self.widgets.append(Button((r.right - 170, y + 5, 136, 40), f"{price:,}원",
                                               lambda it=item, k=kind: self.buy(k, it), 16,
                                               enabled=self.save["money"] >= price))
            y += 56
        self.close_button("나가기")

    def items(self):
        if self.tab == "rod":
            return [(it, "rod") for it in RODS]
        if self.tab == "line":
            return [(it, "line") for it in LINES]
        if self.tab == "hook":
            return [(it, "hook") for it in HOOKS] + [(it, "tool") for it in TOOLS]
        return [(it, "consumable") for it in CONSUMABLES]

    def set_tab(self, k):
        self.tab = k
        self.rebuild()

    def message(self, msg):
        self.flash, self.flash_t = msg, 2.0

    def buy(self, kind, item):
        if self.save["money"] < item["price"]:
            self.sounds.play("error")
            return
        self.save["money"] -= item["price"]
        self.save["owned"].append(item["id"])
        if kind in ("rod", "line", "hook"):
            self.save[kind] = item["id"]
        self.sounds.play("coin")
        self.message(f"{item['name']} 구입 완료!")
        self.save.save()
        self.rebuild()

    def equip(self, kind, item):
        self.save[kind] = item["id"]
        self.message(f"{item['name']} 장착")
        self.rebuild()

    def buy_consumable(self, item, n):
        cost = item["price"] * n
        if self.save["money"] < cost:
            self.sounds.play("error")
            return
        self.save["money"] -= cost
        self.save["stock"][item["id"]] += item["amount"] * n
        self.sounds.play("coin")
        self.message(f"{item['name']} x{n} 구입!")
        self.save.save()
        self.rebuild()

    def update(self, dt):
        self.flash_t = max(0.0, self.flash_t - dt)

    def draw_content(self, surface):
        r = self.rect
        text(surface, f"소지금 {self.save['money']:,}원", (r.right - 30, r.top + 70), 20, (120, 60, 0), bold=True, right=True)
        y = r.top + 116
        for item, kind in self.items():
            row = pygame.Rect(r.left + 24, y, r.w - 48, 50)
            pygame.draw.rect(surface, (240, 222, 168), row, border_radius=4)
            pygame.draw.rect(surface, (170, 138, 78), row, 1, border_radius=4)
            text(surface, item["name"], (row.left + 14, row.top + 4), 19, bold=True)
            if kind == "consumable":
                desc = f"보유: {self.save['stock'][item['id']]}"
            else:
                desc = item["desc"]
            text(surface, desc, (row.left + 14, row.top + 29), 14)
            y += 56
        if self.flash_t > 0:
            text(surface, self.flash, (r.left + 30, r.bottom - 42), 18, (30, 110, 30), bold=True)


# ------------------------------------------------------------------ 확인 (도감/기록)
class RecordPanel(Panel):
    title = "확인 - 어종 도감"
    size = (820, 580)

    def __init__(self, scene):
        self.selected = None
        self.sea = scene.spot.sea
        super().__init__(scene)

    def build(self):
        self.cards = []
        r = self.rect
        self.widgets.append(Button((r.left + 24, r.top + 58, 120, 34), "민물", lambda: self.set_tab(False), 17,
                                   toggled=not self.sea))
        self.widgets.append(Button((r.left + 150, r.top + 58, 120, 34), "바다", lambda: self.set_tab(True), 17,
                                   toggled=self.sea))
        cols = 6
        cw, ch = 124, 100
        fishes = [f for f in FISH if f.sea == self.sea]
        for i, fish in enumerate(fishes):
            cx = r.left + 24 + (i % cols) * (cw + 6)
            cy = r.top + 100 + (i // cols) * (ch + 5)
            self.cards.append((pygame.Rect(cx, cy, cw, ch), fish))
        self.close_button()

    def set_tab(self, sea):
        self.sea = sea
        self.selected = None
        self.rebuild()

    def handle(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, fish in self.cards:
                if rect.collidepoint(event.pos):
                    self.selected = fish
                    self.sounds.play("click")
                    return True
        return super().handle(event)

    def draw_content(self, surface):
        book = self.save["book"]
        for rect, fish in self.cards:
            entry = book.get(fish.id)
            sel = self.selected is fish
            pygame.draw.rect(surface, (250, 236, 190) if sel else (236, 216, 160), rect, border_radius=5)
            pygame.draw.rect(surface, (180, 60, 30) if sel else (160, 128, 68), rect, 2, border_radius=5)
            water = (80, 140, 170) if not fish.sea else (50, 110, 170)
            pygame.draw.rect(surface, water, (rect.left + 6, rect.top + 6, rect.w - 12, 52), border_radius=3)
            size = {"flat": 66, "normal": 80, "long": 96, "eel": 106}[fish.shape]
            gfx.draw_fish(surface, fish, (rect.centerx, rect.top + 32), size, silhouette=entry is None)
            if entry:
                text(surface, fish.name, (rect.centerx, rect.top + 70), 15, bold=True, center=True)
                text(surface, f"{entry['count']}마리 · {entry['max']}cm", (rect.centerx, rect.top + 88), 12, center=True)
            else:
                text(surface, "???", (rect.centerx, rect.top + 76), 18, bold=True, center=True)
        r = self.rect
        info = pygame.Rect(r.left + 24, r.bottom - 124, r.w - 160, 104)
        pygame.draw.rect(surface, (245, 230, 180), info, border_radius=5)
        pygame.draw.rect(surface, (160, 128, 68), info, 2, border_radius=5)
        caught = sum(1 for f in FISH if f.id in book)
        if self.selected:
            fish = self.selected
            entry = book.get(fish.id)
            if entry:
                text(surface, f"{fish.name}  (최대 {entry['max']}cm / {entry['max_w'] / 1000:.2f}kg)",
                     (info.left + 12, info.top + 8), 18, bold=True)
                for i, line in enumerate(wrap_text(fish.desc, 15, info.w - 24)):
                    text(surface, line, (info.left + 12, info.top + 36 + i * 20), 15)
            else:
                text(surface, "아직 낚지 못한 물고기입니다.", (info.left + 12, info.top + 8), 18, bold=True)
                text(surface, self.hint(fish), (info.left + 12, info.top + 36), 15)
        else:
            big = self.save["biggest"]
            big_s = f"{FISH_BY_ID[big['fish']].name} {big['len']}cm" if big else "-"
            lines = [f"발견한 어종: {caught} / {len(FISH)}      총 조과: {self.save['total_catch']}마리",
                     f"최대어: {big_s}      판매 수입: {self.save['total_earned']:,}원",
                     "카드를 누르면 자세한 정보를 볼 수 있습니다."]
            for i, line in enumerate(lines):
                text(surface, line, (info.left + 12, info.top + 10 + i * 30), 17, bold=i < 2)
        if caught == len(FISH):
            text(surface, "★ FishingKing ★", (r.right - 30, r.top + 22), 20, (200, 120, 0), bold=True, right=True)

    @staticmethod
    def hint(fish):
        spots = [s.name.split(". ")[1] for s in SPOTS if fish.id in s.population]
        best = max(fish.baits, key=fish.baits.get)
        when = "밤" if fish.night > fish.day else "낮"
        return f"힌트: {', '.join(spots)} / {BAIT_NAMES[best]} / {when}에 활발"


# ------------------------------------------------------------------ 종료
class QuitPanel(Panel):
    title = "종료"
    size = (440, 240)

    def build(self):
        r = self.rect
        if IS_WEB:     # 브라우저에서는 창을 닫을 수 없으니 타이틀로만
            self.widgets.append(Button((r.left + 60, r.top + 150, 150, 48), "타이틀로", self.to_title, 18))
            self.widgets.append(Button((r.right - 210, r.top + 150, 150, 48), "취소", self.close, 18))
            return
        self.widgets.append(Button((r.left + 24, r.top + 150, 124, 48), "타이틀로", self.to_title, 18))
        self.widgets.append(Button((r.left + 158, r.top + 150, 124, 48), "게임 종료", self.quit, 18))
        self.widgets.append(Button((r.left + 292, r.top + 150, 124, 48), "취소", self.close, 18))

    def draw_content(self, surface):
        text(surface, "기록을 저장하고 나갈까요?" if not IS_WEB else "기록을 저장하고 타이틀로 갈까요?", (self.rect.centerx, self.rect.top + 100), 20, bold=True, center=True)

    def to_title(self):
        self.save.save()
        from .scenes import TitleScene
        self.app.change(TitleScene(self.app))

    def quit(self):
        self.save.save()
        self.app.running = False


# ------------------------------------------------------------------ 조과 (낚은 물고기)
class CatchPanel(Panel):
    title = "월척이오!"
    size = (560, 420)

    def __init__(self, scene, fish, length, weight, price, record, on_done):
        self.fish, self.length, self.weight, self.price = fish, length, weight, price
        self.record = record
        self.on_done = on_done
        self.anim = 0.0
        super().__init__(scene)
        if length < 30:
            self.title = "낚았다!"

    def build(self):
        r = self.rect
        self.widgets.append(Button((r.left + 60, r.bottom - 70, 200, 50), f"판매 (+{self.price:,}원)", self.sell, 18))
        self.widgets.append(Button((r.right - 260, r.bottom - 70, 200, 50), "방생하기", self.release, 18))

    def sell(self):
        self.save["money"] += self.price
        self.save["total_earned"] += self.price
        self.sounds.play("coin")
        self.close()

    def release(self):
        self.close()

    def on_close(self):
        self.on_done()

    def handle(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_s, pygame.K_RETURN, pygame.K_SPACE):
                self.sell()
                return True
            if event.key in (pygame.K_r, pygame.K_ESCAPE):
                self.release()
                return True
        return super().handle(event)

    def update(self, dt):
        self.anim += dt

    def draw_content(self, surface):
        r = self.rect
        water = pygame.Rect(r.left + 30, r.top + 62, r.w - 60, 160)
        pygame.draw.rect(surface, (90, 160, 190), water, border_radius=6)
        for i in range(6):
            yy = water.top + 20 + i * 24
            pygame.draw.line(surface, (140, 200, 225), (water.left + 20 + (i * 37) % 60, yy), (water.left + 90 + (i * 37) % 60, yy), 2)
        px = min(water.w - 40, 120 + self.length * 3.2)
        wobble = math.sin(self.anim * 6) * 4
        gfx.draw_fish(surface, self.fish, (water.centerx, water.centery + wobble), px, angle=math.sin(self.anim * 3) * 4)
        text(surface, self.fish.name, (r.centerx, r.top + 250), 30, bold=True, center=True)
        text(surface, f"{self.length:.1f}cm   {self.weight / 1000:.2f}kg", (r.centerx, r.top + 290), 22, center=True)
        if self.record:
            blink = int(self.anim * 3) % 2 == 0
            text(surface, "★ 신기록! ★", (r.right - 90, r.top + 250), 20, RED if blink else GOLD, bold=True, center=True)
        text(surface, "S: 판매   R: 방생", (r.centerx, r.bottom - 88), 13, center=True)


class MessagePanel(Panel):
    size = (560, 260)

    def __init__(self, scene, title, body):
        self.title = title
        self.body = body
        lines = len(wrap_text(body, 18, 560 - 60))
        self.size = (560, max(260, 170 + lines * 28))      # 글 양에 맞춰 높이 조절
        super().__init__(scene)

    def build(self):
        self.close_button("확인")

    def draw_content(self, surface):
        r = self.rect
        for i, line in enumerate(wrap_text(self.body, 18, r.w - 60)):
            text(surface, line, (r.centerx, r.top + 90 + i * 28), 18, bold=True, center=True)


class UnlockPanel(Panel):
    title = "새로운 낚시터"
    size = (520, 300)

    def __init__(self, scene, region_id, on_unlock):
        self.region = REGION_BY_ID[region_id]
        self.on_unlock = on_unlock
        super().__init__(scene)

    def build(self):
        r = self.rect
        price = self.region["price"]
        self.widgets.append(Button((r.left + 60, r.bottom - 76, 200, 50), f"개방하기 ({price:,}원)", self.unlock, 18,
                                   enabled=self.save["money"] >= price))
        self.widgets.append(Button((r.right - 200, r.bottom - 76, 140, 50), "나중에", self.close, 18))

    def unlock(self):
        self.save["money"] -= self.region["price"]
        self.save["unlocked"].append(self.region["id"])
        self.sounds.play("record")
        self.close()
        self.on_unlock()

    def draw_content(self, surface):
        r = self.rect
        names = ", ".join(s.name.split(". ")[1] for s in SPOTS if s.region == self.region["id"])
        text(surface, f"[{self.region['name']}] 지역은 아직 갈 수 없습니다.", (r.centerx, r.top + 80), 19, bold=True, center=True)
        text(surface, f"낚시터: {names}", (r.centerx, r.top + 112), 16, center=True)
        text(surface, f"한 번 개방하면 언제든 갈 수 있어요.  (소지금 {self.save['money']:,}원)",
             (r.centerx, r.top + 144), 15, center=True)
        if self.save["money"] < self.region["price"]:
            text(surface, "돈이 부족합니다. 강에서 고기를 더 낚아 오세요!", (r.centerx, r.top + 176), 16, RED, bold=True, center=True)
