"""코드로 그리는 2D 그래픽 (배경, 낚시꾼, 물고기, 지도)."""
import math
import random

import pygame

from .settings import HORIZON_Y, NEAR_Y, PLAY_H, SCREEN_W, SKY_DAY_BOTTOM, SKY_DAY_TOP


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_color(c1, c2, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(lerp(a, b, t)) for a, b in zip(c1, c2))


def shade(color, f):
    return tuple(max(0, min(255, int(c * f))) for c in color)


def vgradient(surface, rect, top, bottom):
    rect = pygame.Rect(rect)
    for y in range(rect.h):
        pygame.draw.line(surface, lerp_color(top, bottom, y / max(1, rect.h - 1)),
                         (rect.left, rect.top + y), (rect.right, rect.top + y))


# ------------------------------------------------------------------ 원근
def water_y(distance):
    """거리(m) -> 화면 y."""
    k = 4.0 / (distance + 4.0)
    return HORIZON_Y + 8 + (NEAR_Y - HORIZON_Y) * k


def water_scale(distance):
    return 4.0 / (distance + 4.0)


# ------------------------------------------------------------------ 배경
def _tree_cluster(surface, rng, x, y, r, base):
    for _ in range(7):
        ox, oy = rng.randint(-r, r), rng.randint(-r // 2, r // 3)
        rr = rng.randint(r // 2, r)
        pygame.draw.circle(surface, shade(base, rng.uniform(0.75, 1.15)), (x + ox, y + oy), rr)
    for _ in range(5):
        ox, oy = rng.randint(-r, r), rng.randint(-r, 0)
        pygame.draw.circle(surface, shade(base, rng.uniform(1.15, 1.35)), (x + ox, y + oy), rng.randint(3, r // 2 + 3))


def _mountains(surface, rng, base_y, amp, color, seed_shift):
    pts = [(0, PLAY_H)]
    for x in range(0, SCREEN_W + 20, 16):
        y = base_y - amp * (0.55 * math.sin(x / 130 + seed_shift) + 0.3 * math.sin(x / 57 + seed_shift * 2)
                            + 0.15 * math.sin(x / 23 + seed_shift * 3))
        pts.append((x, y))
    pts.append((SCREEN_W, PLAY_H))
    pygame.draw.polygon(surface, color, pts)


def _islands(surface, rng):
    """바다 수평선 위의 먼 섬들."""
    for _ in range(3):
        cx = rng.randint(80, SCREEN_W - 80)
        w = rng.randint(120, 300)
        h = rng.randint(18, 45)
        pts = [(cx - w // 2, HORIZON_Y + 2)]
        for i in range(1, 12):
            x = cx - w // 2 + w * i / 12
            y = HORIZON_Y + 2 - h * math.sin(math.pi * i / 12) * rng.uniform(0.75, 1.0)
            pts.append((x, y))
        pts.append((cx + w // 2, HORIZON_Y + 2))
        pygame.draw.polygon(surface, (120, 150, 160), pts)


def _far_forest(spot, rng):
    tree_base = {"rapids": (60, 120, 60), "weeds": (50, 110, 50), "deep": (40, 90, 55), "reeds": (80, 120, 60),
                 "dam": (35, 85, 50), "reservoir": (70, 120, 60)}[spot.feature]
    far = pygame.Surface((SCREEN_W, 130), pygame.SRCALPHA)
    for x in range(-20, SCREEN_W + 40, 26):
        _tree_cluster(far, rng, x, rng.randint(60, 85), rng.randint(20, 34), tree_base)
    pygame.draw.rect(far, shade(tree_base, 0.8), (0, 100, SCREEN_W, 30))
    if spot.feature == "deep":
        pts = [(0, 130), (0, 10), (60, 0), (140, 30), (220, 60), (300, 130)]
        pygame.draw.polygon(far, (120, 110, 100), pts)
        for _ in range(12):
            x, y = rng.randint(0, 250), rng.randint(20, 120)
            pygame.draw.line(far, (90, 85, 80), (x, y), (x + rng.randint(10, 30), y + rng.randint(-5, 5)), 2)
    elif spot.feature == "dam":
        # 콘크리트 댐 벽
        wall = [(560, 130), (590, 40), (SCREEN_W + 10, 40), (SCREEN_W + 10, 130)]
        pygame.draw.polygon(far, (185, 185, 180), wall)
        pygame.draw.rect(far, (150, 150, 145), (590, 32, SCREEN_W - 580, 10))
        for x in range(600, SCREEN_W, 36):
            pygame.draw.line(far, (160, 160, 155), (x, 44), (x - 8, 128), 2)
        for x in range(610, SCREEN_W, 72):
            pygame.draw.rect(far, (120, 120, 118), (x, 22, 16, 14))
    elif spot.feature == "reservoir":
        # 제방 (둑)
        pygame.draw.polygon(far, (120, 150, 80), [(0, 130), (0, 70), (420, 76), (500, 130)])
        pygame.draw.line(far, (180, 170, 130), (0, 70), (420, 76), 4)
        for x in range(20, 420, 60):
            pygame.draw.line(far, (70, 60, 50), (x, 70), (x, 58), 2)
    return far


def _foreground_grass(surf, rng):
    for x in range(-10, SCREEN_W + 10, 5):
        if abs(x - SCREEN_W // 2) < 200 and rng.random() < 0.6:
            continue
        h = rng.randint(10, 60) if abs(x - SCREEN_W // 2) > 300 else rng.randint(5, 25)
        pygame.draw.line(surf, rng.choice([(40, 110, 40), (60, 140, 50), (30, 90, 35)]),
                         (x, PLAY_H), (x + rng.randint(-10, 10), PLAY_H - h), 3)


def _rock(surf, rng, cx, cy, w, h, base=(90, 88, 85)):
    pts = []
    for i in range(10):
        a = math.pi + math.pi * i / 9
        pts.append((cx + math.cos(a) * w / 2 * rng.uniform(0.8, 1.05), cy + math.sin(a) * h * rng.uniform(0.7, 1.0)))
    pts.append((cx + w / 2, cy + 30))
    pts.append((cx - w / 2, cy + 30))
    pygame.draw.polygon(surf, base, pts)
    for _ in range(6):
        x = cx + rng.randint(-w // 3, w // 3)
        y = cy - rng.randint(0, int(h * 0.7))
        pygame.draw.line(surf, shade(base, 1.3), (x, y), (x + rng.randint(8, 25), y + rng.randint(-4, 4)), 2)


def build_background(spot, night):
    """낚시 화면 배경을 한 번 그려서 Surface 로 돌려준다."""
    rng = random.Random(ord(spot.key[0]) * 97)
    surf = pygame.Surface((SCREEN_W, PLAY_H))
    feat = spot.feature

    # 하늘
    vgradient(surf, (0, 0, SCREEN_W, HORIZON_Y), SKY_DAY_TOP, SKY_DAY_BOTTOM)
    for _ in range(6):
        cx, cy = rng.randint(0, SCREEN_W), rng.randint(20, 150)
        for _ in range(6):
            pygame.draw.ellipse(surf, (245, 248, 252),
                                (cx + rng.randint(-50, 50), cy + rng.randint(-10, 10), rng.randint(50, 110), rng.randint(18, 30)))

    water_top = HORIZON_Y + 6
    far = None
    if spot.sea:
        _islands(surf, rng)
        water_top = HORIZON_Y + 2
    else:
        amp = 90 if feat == "dam" else (25 if feat == "reservoir" else 50)
        _mountains(surf, rng, 220, amp, (150, 170, 190), rng.uniform(0, 6))
        _mountains(surf, rng, 250, amp * 0.7, (110, 140, 130), rng.uniform(0, 6))
        far = _far_forest(spot, rng)
        surf.blit(far, (0, HORIZON_Y - 120))
        for x in range(0, SCREEN_W, 14):
            c = rng.randint(130, 180)
            pygame.draw.ellipse(surf, (c, c, c - 5), (x + rng.randint(-4, 4), HORIZON_Y + rng.randint(-8, 2),
                                                      rng.randint(14, 30), rng.randint(6, 11)))

    # 수면
    far_col = lerp_color(spot.water, (200, 230, 240), 0.35)
    near_col = shade(spot.water, 0.75)
    vgradient(surf, (0, water_top, SCREEN_W, PLAY_H - water_top), far_col, near_col)
    if far is not None:
        refl = pygame.transform.flip(far, False, True)
        refl.set_alpha(70)
        surf.blit(refl, (0, water_top - 4), area=pygame.Rect(0, 0, SCREEN_W, 90))
    if spot.sea:
        pygame.draw.line(surf, (230, 240, 245), (0, HORIZON_Y + 2), (SCREEN_W, HORIZON_Y + 2), 1)
        for _ in range(60):
            d = rng.uniform(3, 60)
            y = water_y(d)
            s = water_scale(d)
            x = rng.randint(0, SCREEN_W)
            pygame.draw.arc(surf, shade(spot.water, 1.35), (x, y - 4 * s, 60 * s + 8, 10 * s + 3), 0.3, 2.8, 1)

    # 지형 특징
    if feat == "rapids":
        for _ in range(9):
            d = rng.uniform(4, 25)
            y = water_y(d)
            x = rng.randint(0, SCREEN_W)
            s = water_scale(d)
            w, h = int(70 * s + 12), int(26 * s + 5)
            pygame.draw.ellipse(surf, (110, 110, 105), (x, y - h // 2, w, h))
            pygame.draw.ellipse(surf, (150, 150, 145), (x + 3, y - h // 2 + 1, w - 10, h // 2))
            pygame.draw.ellipse(surf, (230, 240, 240), (x - 8, y + h // 3, w + 16, h // 2), 2)
    elif feat in ("weeds", "reservoir"):
        for _ in range(26 if feat == "weeds" else 12):
            d = rng.uniform(2, 20)
            side = rng.choice([-1, 1])
            cx = SCREEN_W // 2 + side * rng.randint(200, 520)
            y = water_y(d)
            s = water_scale(d)
            w, h = int(80 * s + 10), int(30 * s + 4)
            pygame.draw.ellipse(surf, (50, 130, 50), (cx - w // 2, y - h // 2, w, h))
            pygame.draw.ellipse(surf, (80, 160, 70), (cx - w // 2 + 3, y - h // 2 + 2, w - 12, h - 8))
            pygame.draw.line(surf, (40, 100, 40), (cx, y), (cx + w // 2 - 2, y - 2), 2)
            if rng.random() < 0.2:
                pygame.draw.circle(surf, (250, 180, 210), (cx - w // 5, y - h // 3), max(3, int(8 * s)))
        if feat == "reservoir":
            # 좌대 (물 위 낚시 발판)
            for d, x in ((30, 180), (45, 720), (22, 820)):
                y = water_y(d)
                s = water_scale(d)
                w, h = int(160 * s), int(90 * s)
                pygame.draw.rect(surf, (150, 110, 60), (x - w // 2, y - 6 * s, w, 10 * s))
                pygame.draw.rect(surf, (210, 200, 170), (x - w // 4, y - h, w // 2, h - 6 * s))
                pygame.draw.polygon(surf, (60, 110, 170), [(x - w // 3, y - h), (x, y - h - 30 * s), (x + w // 3, y - h)])
    elif feat == "reeds":
        for side in (-1, 1):
            for _ in range(70):
                x = SCREEN_W // 2 + side * rng.randint(260, 500)
                base = rng.randint(HORIZON_Y + 30, PLAY_H)
                hgt = rng.randint(50, 150)
                lean = rng.randint(-15, 15)
                col = rng.choice([(170, 150, 80), (150, 130, 70), (190, 170, 100)])
                pygame.draw.line(surf, col, (x, base), (x + lean, base - hgt), 2)
                pygame.draw.ellipse(surf, (140, 100, 60), (x + lean - 4, base - hgt - 16, 8, 20))
    elif feat == "breakwater":
        # 멀리 보이는 빨간 등대가 있는 방파제
        y = water_y(70)
        pygame.draw.rect(surf, (200, 200, 195), (620, y - 10, 340, 12))
        pygame.draw.rect(surf, (210, 50, 40), (700, y - 70, 20, 62))
        pygame.draw.rect(surf, (240, 240, 240), (700, y - 50, 20, 8))
        pygame.draw.rect(surf, (80, 80, 80), (696, y - 80, 28, 10))
        # 테트라포드
        for side in (-1, 1):
            for i in range(9):
                cx = SCREEN_W // 2 + side * (280 + i * 26 + rng.randint(-10, 10))
                cy = PLAY_H - 60 - rng.randint(0, 120)
                c = rng.randint(150, 190)
                for a in range(3):
                    ang = a * 2.09 + rng.uniform(0, 1)
                    pygame.draw.line(surf, (c, c, c - 6), (cx, cy), (cx + math.cos(ang) * 30, cy + math.sin(ang) * 30), 16)
                pygame.draw.circle(surf, (c + 20, c + 20, c + 15), (cx, cy), 10)
        # 발밑 콘크리트
        pygame.draw.polygon(surf, (175, 175, 170), [(200, PLAY_H), (270, PLAY_H - 70), (690, PLAY_H - 70), (760, PLAY_H)])
        pygame.draw.line(surf, (215, 215, 210), (270, PLAY_H - 70), (690, PLAY_H - 70), 4)
    elif feat == "rocks":
        _rock(surf, rng, 880, water_y(12), 260, 90, (80, 78, 75))
        for i in range(5):
            y = water_y(12) + 14 + i * 5
            pygame.draw.arc(surf, (235, 242, 248), (730 + i * 18, y, 90, 14), 0.2, 2.9, 2)
        _rock(surf, rng, 150, water_y(30), 200, 50, (95, 92, 88))
        _rock(surf, rng, 90, PLAY_H - 40, 300, 150, (70, 68, 66))
        _rock(surf, rng, SCREEN_W - 70, PLAY_H - 30, 320, 170, (75, 72, 70))
        _rock(surf, rng, SCREEN_W // 2, PLAY_H + 10, 520, 80, (85, 82, 78))
    elif feat == "boat":
        # 배 앞머리
        deck = [(120, PLAY_H), (200, PLAY_H - 95), (760, PLAY_H - 95), (840, PLAY_H)]
        pygame.draw.polygon(surf, (235, 235, 235), deck)
        pygame.draw.polygon(surf, (150, 110, 70), [(215, PLAY_H), (260, PLAY_H - 78), (700, PLAY_H - 78), (745, PLAY_H)])
        for x in range(260, 700, 30):
            pygame.draw.line(surf, (120, 85, 55), (x, PLAY_H - 78), (x - (x - 480) * 0.2, PLAY_H), 1)
        pygame.draw.line(surf, (40, 80, 160), (200, PLAY_H - 95), (760, PLAY_H - 95), 6)
        pygame.draw.line(surf, (200, 40, 40), (160, PLAY_H - 48), (800, PLAY_H - 48), 4)
        # 갈매기
        for _ in range(5):
            x, y = rng.randint(100, 860), rng.randint(60, 180)
            pygame.draw.arc(surf, (250, 250, 250), (x, y, 16, 10), 0.2, 3.0, 2)
            pygame.draw.arc(surf, (250, 250, 250), (x + 14, y, 16, 10), 0.2, 3.0, 2)
    if feat == "dam":
        for side in (-1, 1):
            for _ in range(14):
                x = SCREEN_W // 2 + side * rng.randint(230, 520)
                y = PLAY_H - rng.randint(0, 60)
                c = rng.randint(110, 160)
                pygame.draw.ellipse(surf, (c, c - 5, c - 12), (x - 30, y - 18, rng.randint(40, 80), rng.randint(24, 40)))
    elif not spot.sea:
        _foreground_grass(surf, rng)

    if night:
        tint = pygame.Surface(surf.get_size())
        tint.fill((70, 80, 130))
        surf.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)
        sky_tint = pygame.Surface((SCREEN_W, HORIZON_Y))
        vgradient(sky_tint, sky_tint.get_rect(), (110, 110, 150), (190, 190, 210))
        surf.blit(sky_tint, (0, 0), special_flags=pygame.BLEND_MULT)
        for _ in range(110):
            x, y = rng.randint(0, SCREEN_W), rng.randint(0, 150)
            b = rng.randint(150, 255)
            surf.set_at((x, y), (b, b, b))
            if rng.random() < 0.1:
                pygame.draw.circle(surf, (b, b, b), (x, y), 1)
        # 달 + 달빛 반영
        pygame.draw.circle(surf, (250, 245, 210), (760, 80), 28)
        pygame.draw.circle(surf, (230, 225, 190), (750, 72), 6)
        pygame.draw.circle(surf, (235, 230, 195), (770, 92), 4)
        for i in range(14):
            y = HORIZON_Y + 14 + i * 12
            w = 20 + i * 5
            pygame.draw.line(surf, (160, 160, 150), (760 - w // 2 + rng.randint(-5, 5), y), (760 + w // 2, y), 2)
        if feat == "boat":
            # 집어등
            for x in (230, 730):
                glow = pygame.Surface((160, 160), pygame.SRCALPHA)
                pygame.draw.circle(glow, (255, 240, 170, 38), (80, 80), 78)
                pygame.draw.circle(glow, (255, 245, 190, 50), (80, 80), 40)
                pygame.draw.circle(glow, (255, 255, 230, 220), (80, 80), 12)
                surf.blit(glow, (x - 80, PLAY_H - 200))
                pygame.draw.line(surf, (60, 60, 60), (x, PLAY_H - 110), (x, PLAY_H - 95), 3)
    return surf


# ------------------------------------------------------------------ 낚시꾼
ANGLER_X = 470
HAND = (556, PLAY_H - 118)
ROD_TIP = (660, 70)


def draw_angler(surface, night=False, lean=0.0):
    f = 0.55 if night else 1.0
    x = ANGLER_X + int(lean * 6)
    by = PLAY_H
    # 의자
    pygame.draw.rect(surface, shade((90, 70, 40), f), (x - 60, by - 30, 120, 30))
    # 몸통 (조끼)
    body = [(x - 70, by), (x - 62, by - 112), (x + 62, by - 112), (x + 70, by)]
    pygame.draw.polygon(surface, shade((170, 170, 165), f), body)
    pygame.draw.polygon(surface, shade((40, 70, 170), f), [(x - 62, by - 50), (x + 62, by - 50), (x + 66, by - 15), (x - 66, by - 15)])
    pygame.draw.rect(surface, shade((230, 230, 230), f), (x - 38, by - 46, 76, 24), border_radius=3)
    from .ui import text
    text(surface, "F K", (x, by - 34), 18, shade((40, 60, 160), f), bold=True, center=True)
    pygame.draw.line(surface, shade((120, 120, 115), f), (x, by - 112), (x, by - 52), 2)
    # 팔
    pygame.draw.line(surface, shade((50, 80, 190), f), (x - 55, by - 105), (x - 20, by - 150), 20)
    pygame.draw.line(surface, shade((50, 80, 190), f), (x + 55, by - 105), (HAND[0] + int(lean * 6), HAND[1]), 20)
    pygame.draw.circle(surface, shade((230, 190, 160), f), (x - 18, by - 154), 10)
    pygame.draw.circle(surface, shade((230, 190, 160), f), (HAND[0] + int(lean * 6), HAND[1]), 10)
    # 머리
    pygame.draw.circle(surface, shade((90, 60, 30), f), (x, by - 140), 30)
    pygame.draw.ellipse(surface, shade((40, 70, 180), f), (x - 32, by - 178, 64, 40))
    pygame.draw.ellipse(surface, shade((30, 55, 150), f), (x - 30, by - 146, 60, 10))


def draw_rod(surface, tip, bend=0.0, lean=0.0, night=False):
    hand = (HAND[0] + int(lean * 6), HAND[1])
    ctrl = (lerp(hand[0], ROD_TIP[0], 0.65), lerp(hand[1], ROD_TIP[1], 0.65))
    pts = []
    for i in range(21):
        t = i / 20
        x = (1 - t) ** 2 * hand[0] + 2 * (1 - t) * t * ctrl[0] + t * t * tip[0]
        y = (1 - t) ** 2 * hand[1] + 2 * (1 - t) * t * ctrl[1] + t * t * tip[1]
        pts.append((x, y))
    col = (90, 50, 30) if not night else (60, 40, 30)
    for i in range(20):
        w = max(1, int(5 - i * 0.22))
        pygame.draw.line(surface, col, pts[i], pts[i + 1], w)
    pygame.draw.circle(surface, (40, 40, 40), (int(hand[0] + 8), int(hand[1] - 16)), 7)  # 릴
    return pts[-1]


def rod_tip_for(bend, target_x):
    """장력(0~1)에 따라 휘어진 초리 위치."""
    dx = max(-1, min(1, (target_x - ROD_TIP[0]) / 300))
    return (ROD_TIP[0] + dx * 60 * bend, ROD_TIP[1] + 150 * bend)


# ------------------------------------------------------------------ 찌
def draw_float(surface, x, y, scale, offset, glow=False, night=False):
    """offset: +1 이면 찌가 솟음, -1 이면 완전히 잠김."""
    full = 100 * scale + 14
    visible = full * max(0.0, min(1.0, 0.45 + 0.45 * offset))
    w = max(3, int(7 * scale + 3))
    if visible > 1:
        top = y - visible
        seg = full / 5
        cols = [(230, 40, 30), (250, 210, 30), (230, 40, 30), (40, 160, 60), (240, 240, 240)]
        if night and not glow:
            cols = [shade(c, 0.35) for c in cols]
        yy = y
        i = 4
        while yy > top and i >= 0:
            seg_top = max(top, yy - seg)
            pygame.draw.rect(surface, cols[i], (x - w // 2, seg_top, w, yy - seg_top))
            yy -= seg
            i -= 1
        if glow:
            g = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.circle(g, (120, 255, 120, 90), (15, 15), 14)
            pygame.draw.circle(g, (180, 255, 180, 200), (15, 15), 5)
            surface.blit(g, (x - 15, top - 15))
    pygame.draw.ellipse(surface, (220, 235, 240) if not night else (90, 100, 120),
                        (x - 8 * scale - 3, y - 2, 16 * scale + 6, 5), 1)


def draw_float_zoom(surface, rect, offset, lying, night, glow, water_col, t):
    """찌 확대창."""
    rect = pygame.Rect(rect)
    old_clip = surface.get_clip()
    surface.set_clip(rect)
    line_y = rect.top + int(rect.h * 0.6)
    sky = (30, 36, 70) if night else (200, 225, 240)
    vgradient(surface, (rect.left, rect.top, rect.w, line_y - rect.top), shade(sky, 0.8), sky)
    wc = shade(water_col, 0.45 if night else 1.0)
    vgradient(surface, (rect.left, line_y, rect.w, rect.bottom - line_y), wc, shade(wc, 0.6))
    cx = rect.centerx
    cols = [(230, 40, 30), (250, 210, 30), (230, 40, 30), (40, 160, 60), (240, 240, 240)]
    if night and not glow:
        cols = [shade(c, 0.4) for c in cols]
    if lying:
        y = line_y - 3 - int(offset * 5)
        pygame.draw.rect(surface, cols[0], (cx - 50, y, 40, 7))
        pygame.draw.rect(surface, cols[1], (cx - 10, y, 30, 7))
        pygame.draw.rect(surface, cols[4], (cx + 20, y, 30, 7))
    else:
        full = rect.h * 0.62
        visible = full * max(0.0, min(1.0, 0.45 + 0.45 * offset))
        top = line_y - visible
        seg = full / 5
        for i, c in enumerate(cols):
            pygame.draw.rect(surface, c, (cx - 6, top + i * seg, 12, seg + 1))
        pygame.draw.polygon(surface, (240, 240, 240), [(cx - 6, top + full), (cx + 6, top + full), (cx, top + full + 30)])
        if glow:
            g = pygame.Surface((60, 60), pygame.SRCALPHA)
            pygame.draw.circle(g, (120, 255, 120, 80), (30, 30), 28)
            pygame.draw.circle(g, (200, 255, 200, 220), (30, 30), 8)
            surface.blit(g, (cx - 30, top - 30))
        # 물속 부분은 흐리게
        under = pygame.Surface((rect.w, rect.bottom - line_y), pygame.SRCALPHA)
        under.fill((*wc, 170))
        surface.blit(under, (rect.left, line_y))
    wob = math.sin(t * 3) * 3
    ring = 36 + abs(offset) * 60
    pygame.draw.ellipse(surface, (235, 245, 250), (cx - ring / 2, line_y - 4 + wob * 0.2, ring, 9), 2)
    pygame.draw.line(surface, shade(wc, 1.4), (rect.left, line_y), (rect.right, line_y), 2)
    surface.set_clip(old_clip)


def draw_ripple(surface, x, y, radius, alpha, scale):
    if alpha <= 0:
        return
    w, h = int(radius * 2 * scale) + 4, int(radius * 0.7 * scale) + 2
    s = pygame.Surface((w + 4, h + 4), pygame.SRCALPHA)
    pygame.draw.ellipse(s, (235, 245, 250, int(alpha)), (2, 2, w, h), 2)
    surface.blit(s, (x - w // 2 - 2, y - h // 2 - 2))


# ------------------------------------------------------------------ 물고기
def draw_fish(surface, fish, center, length, facing=1, silhouette=False, angle=0):
    """length: 픽셀 길이."""
    L = max(12, int(length))
    if fish.shape == "eel":
        H = max(4, int(L * 0.1))
    elif fish.shape == "long":
        H = max(5, int(L * 0.24))
    elif fish.shape == "flat":
        H = max(6, int(L * 0.42))
    else:
        H = max(6, int(L * 0.32))
    pad = 6
    s = pygame.Surface((L + pad * 2, H * 2 + pad * 2), pygame.SRCALPHA)
    cy = s.get_height() // 2
    body_col = (25, 35, 45) if silhouette else fish.color
    belly_col = (25, 35, 45) if silhouette else fish.belly
    body_len = int(L * 0.8)
    if fish.shape == "eel":
        pts = []
        for i in range(body_len):
            pts.append((pad + i, cy + math.sin(i / 10) * 2))
        for i, p in enumerate(pts):
            pygame.draw.circle(s, body_col, (int(p[0]), int(p[1])), max(2, int(H * (1 - i / len(pts) * 0.5))))
        tail_x = pad + body_len
        pygame.draw.polygon(s, body_col, [(tail_x - 4, cy - H // 2), (tail_x + L * 0.18, cy), (tail_x - 4, cy + H // 2)])
    else:
        body = pygame.Rect(pad, cy - H // 2, body_len, H)
        pygame.draw.ellipse(s, body_col, body)
        if not silhouette:
            pygame.draw.ellipse(s, belly_col, (pad + body_len * 0.1, cy, body_len * 0.75, H // 2))
        tail_x = pad + body_len - 4
        pygame.draw.polygon(s, body_col, [(tail_x, cy), (pad + L, cy - H * 0.55), (pad + L - L * 0.06, cy),
                                          (pad + L, cy + H * 0.55)])
        # 등지느러미
        pygame.draw.polygon(s, shade(body_col, 0.8), [(pad + body_len * 0.35, cy - H // 2 + 1),
                                                      (pad + body_len * 0.5, cy - H * 0.75),
                                                      (pad + body_len * 0.7, cy - H // 2 + 2)])
        if not silhouette:
            # 비늘 무늬
            for i in range(3, 8):
                xx = pad + body_len * i / 9
                pygame.draw.arc(s, shade(body_col, 0.8), (xx - 4, cy - H // 4, 8, H // 2), -1.2, 1.2, 1)
            if fish.id == "mandarin":
                for i in range(4):
                    pygame.draw.circle(s, (80, 60, 30), (int(pad + body_len * (0.3 + i * 0.15)), cy - H // 6), max(2, H // 7))
            if fish.id == "catfish":
                pygame.draw.line(s, (40, 40, 30), (pad + 4, cy), (pad - 2, cy + H // 2), 2)
                pygame.draw.line(s, (40, 40, 30), (pad + 4, cy - 2), (pad - 3, cy - H // 3), 2)
    if not silhouette:
        ex, ey = pad + max(4, int(L * 0.09)), cy - max(1, H // 7)
        pygame.draw.circle(s, (250, 250, 250), (ex, ey), max(2, H // 7))
        pygame.draw.circle(s, (10, 10, 10), (ex, ey), max(1, H // 12))
    if facing > 0:
        s = pygame.transform.flip(s, True, False)
    if angle:
        s = pygame.transform.rotate(s, angle)
    surface.blit(s, s.get_rect(center=(int(center[0]), int(center[1]))))


# ------------------------------------------------------------------ 지도
MAP_RIVER = [(990, 190), (860, 250), (760, 210), (640, 190), (520, 260), (420, 300),
             (300, 290), (180, 360), (80, 430), (-30, 460)]
MAP_WIDTH = [60, 70, 120, 170, 230, 250, 220, 150, 110, 100]


def _catmull(points, samples=12):
    out = []
    pts = [points[0]] + points + [points[-1]]
    for i in range(1, len(pts) - 2):
        p0, p1, p2, p3 = pts[i - 1], pts[i], pts[i + 1], pts[i + 2]
        for j in range(samples):
            t = j / samples
            t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2
                                    + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3) for k in range(2)))
    out.append(points[-1])
    return out


def river_geometry():
    center = _catmull(MAP_RIVER)
    widths = []
    n = len(MAP_RIVER) - 1
    for i in range(len(center)):
        f = i / (len(center) - 1) * n
        a = int(f)
        b = min(n, a + 1)
        widths.append(lerp(MAP_WIDTH[a], MAP_WIDTH[b], f - a))
    left, right = [], []
    for i, (x, y) in enumerate(center):
        x2, y2 = center[min(len(center) - 1, i + 1)]
        x1, y1 = center[max(0, i - 1)]
        dx, dy = x2 - x1, y2 - y1
        ln = math.hypot(dx, dy) or 1
        nx, ny = -dy / ln, dx / ln
        w = widths[i] / 2
        left.append((x + nx * w, y + ny * w))
        right.append((x - nx * w, y - ny * w))
    return center, widths, left, right


def build_map(night=False):
    rng = random.Random(7)
    surf = pygame.Surface((SCREEN_W, PLAY_H))
    surf.fill((70, 130, 60))
    # 논밭
    for _ in range(40):
        x, y = rng.randint(-40, SCREEN_W), rng.randint(-40, PLAY_H)
        w, h = rng.randint(60, 150), rng.randint(40, 90)
        col = rng.choice([(110, 150, 70), (130, 160, 80), (150, 140, 80), (90, 140, 60)])
        pygame.draw.rect(surf, col, (x, y, w, h))
        pygame.draw.rect(surf, shade(col, 0.8), (x, y, w, h), 2)
        for yy in range(y + 8, y + h, 8):
            pygame.draw.line(surf, shade(col, 0.9), (x + 3, yy), (x + w - 3, yy), 1)
    center, widths, left, right = river_geometry()
    # 모래톱
    sand_l = [(x + (lx - x) * 1.25, y + (ly - y) * 1.25) for (x, y), (lx, ly) in zip(center, left)]
    sand_r = [(x + (rx - x) * 1.25, y + (ry - y) * 1.25) for (x, y), (rx, ry) in zip(center, right)]
    pygame.draw.polygon(surf, (200, 170, 110), sand_l + sand_r[::-1])
    pygame.draw.polygon(surf, (50, 110, 170), left + right[::-1])
    inner_l = [(x + (lx - x) * 0.6, y + (ly - y) * 0.6) for (x, y), (lx, ly) in zip(center, left)]
    inner_r = [(x + (rx - x) * 0.6, y + (ry - y) * 0.6) for (x, y), (rx, ry) in zip(center, right)]
    pygame.draw.polygon(surf, (40, 95, 160), inner_l + inner_r[::-1])
    # 물결
    for _ in range(260):
        i = rng.randint(0, len(center) - 1)
        t = rng.uniform(-0.45, 0.45)
        x = center[i][0] + (left[i][0] - center[i][0]) * t * 2
        y = center[i][1] + (left[i][1] - center[i][1]) * t * 2
        pygame.draw.line(surf, (150, 200, 235), (x, y), (x + rng.randint(3, 8), y), 1)
    # 섬
    isl = (470, 285)
    pygame.draw.ellipse(surf, (200, 170, 110), (isl[0] - 110, isl[1] - 45, 220, 90))
    pygame.draw.ellipse(surf, (60, 120, 50), (isl[0] - 95, isl[1] - 38, 190, 70))
    for _ in range(14):
        pygame.draw.circle(surf, shade((50, 110, 45), rng.uniform(0.8, 1.2)),
                           (isl[0] + rng.randint(-75, 75), isl[1] + rng.randint(-25, 18)), rng.randint(8, 16))
    # 숲, 집
    for _ in range(90):
        x, y = rng.randint(0, SCREEN_W), rng.randint(0, PLAY_H)
        if _near_river(center, widths, x, y, 1.6):
            continue
        _tree_cluster(surf, rng, x, y, rng.randint(10, 18), (40, 100, 40))
    for _ in range(14):
        x, y = rng.randint(0, SCREEN_W), rng.randint(0, PLAY_H)
        if _near_river(center, widths, x, y, 1.8):
            continue
        for k in range(rng.randint(2, 5)):
            hx, hy = x + k * 14, y + rng.randint(-6, 6)
            pygame.draw.rect(surf, (230, 230, 220), (hx, hy, 11, 9))
            pygame.draw.polygon(surf, rng.choice([(60, 90, 180), (200, 110, 40)]), [(hx - 2, hy), (hx + 5, hy - 6), (hx + 13, hy)])
    if night:
        tint = pygame.Surface(surf.get_size())
        tint.fill((80, 90, 140))
        surf.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)
    return surf


def _near_river(center, widths, x, y, factor):
    for (cx, cy), w in zip(center[::3], widths[::3]):
        if math.hypot(cx - x, cy - y) < w / 2 * factor + 12:
            return True
    return False


def map_marker_positions():
    """A~D 포인트 위치 (강둑 위)."""
    center, widths, left, right = river_geometry()
    n = len(center) - 1

    def at(t, side):
        i = int(t * n)
        pts = left if side > 0 else right
        return (int(pts[i][0]), int(pts[i][1]))
    return {"A": at(0.10, 1), "B": at(0.52, -1), "C": at(0.30, 1), "D": at(0.62, 1)}


def draw_map_marker(surface, pos, letter, selected, hover):
    from .ui import text
    x, y = pos
    col = (240, 230, 200) if not selected else (255, 210, 90)
    if hover:
        col = (255, 245, 215) if not selected else (255, 225, 120)
    pygame.draw.ellipse(surface, (40, 40, 30), (x - 54, y - 16, 100, 36))
    pygame.draw.ellipse(surface, col, (x - 56, y - 19, 100, 36))
    pygame.draw.polygon(surface, col, [(x + 38, y - 1), (x + 62, y - 16), (x + 62, y + 14)])
    pygame.draw.ellipse(surface, (80, 70, 50), (x - 56, y - 19, 100, 36), 2)
    pygame.draw.circle(surface, (30, 30, 30), (x - 38, y - 5), 3)
    pygame.draw.circle(surface, (30, 40, 90), (x, y - 1), 13)
    text(surface, letter, (x, y - 2), 18, (255, 255, 255), bold=True, center=True)


def _blob(cx, cy, rx, ry, rng, n=28, rough=0.18):
    pts = []
    phase = rng.uniform(0, 6)
    for i in range(n):
        a = 2 * math.pi * i / n
        r = 1 + rough * math.sin(a * 3 + phase) + rough * 0.5 * math.sin(a * 7 + phase * 2)
        pts.append((cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r))
    return pts


def _land(surf, rng, avoid):
    surf.fill((70, 130, 60))
    for _ in range(30):
        x, y = rng.randint(-40, SCREEN_W), rng.randint(-40, PLAY_H)
        w, h = rng.randint(60, 150), rng.randint(40, 90)
        col = rng.choice([(110, 150, 70), (130, 160, 80), (150, 140, 80), (90, 140, 60)])
        pygame.draw.rect(surf, col, (x, y, w, h))
        pygame.draw.rect(surf, shade(col, 0.8), (x, y, w, h), 2)
    for _ in range(110):
        x, y = rng.randint(0, SCREEN_W), rng.randint(0, PLAY_H)
        if not avoid(x, y):
            _tree_cluster(surf, rng, x, y, rng.randint(10, 18), (40, 100, 40))


def _houses(surf, rng, x, y, n):
    for k in range(n):
        hx, hy = x + (k % 4) * 16, y + (k // 4) * 16 + rng.randint(-3, 3)
        pygame.draw.rect(surf, (230, 230, 220), (hx, hy, 12, 9))
        pygame.draw.polygon(surf, rng.choice([(60, 90, 180), (200, 110, 40)]), [(hx - 2, hy), (hx + 6, hy - 6), (hx + 14, hy)])


def build_lake_map(night=False):
    rng = random.Random(11)
    surf = pygame.Surface((SCREEN_W, PLAY_H))
    dam = _blob(700, 280, 230, 200, rng)
    res = _blob(230, 390, 150, 110, rng, rough=0.1)
    dam_poly = pygame.Rect(440, 50, 500, 470)
    res_poly = pygame.Rect(60, 260, 340, 260)
    _land(surf, rng, lambda x, y: dam_poly.inflate(40, 40).collidepoint(x, y) or res_poly.inflate(30, 30).collidepoint(x, y))
    # 짙은 산
    for _ in range(40):
        x, y = rng.randint(420, SCREEN_W), rng.choice([rng.randint(0, 60), rng.randint(520, PLAY_H)])
        pygame.draw.circle(surf, shade((30, 80, 35), rng.uniform(0.8, 1.2)), (x, y), rng.randint(14, 30))
    # 댐 호수
    pygame.draw.polygon(surf, (180, 160, 110), [(x + (x - 700) * 0.06, y + (y - 280) * 0.06) for x, y in dam])
    pygame.draw.polygon(surf, (30, 80, 150), dam)
    pygame.draw.polygon(surf, (25, 65, 130), [(700 + (x - 700) * 0.6, 280 + (y - 280) * 0.6) for x, y in dam])
    # 댐 벽과 방류 하천
    pygame.draw.line(surf, (200, 200, 195), (760, 500), (900, 430), 14)
    pygame.draw.line(surf, (150, 150, 145), (760, 500), (900, 430), 2)
    pygame.draw.lines(surf, (60, 120, 180), False, [(840, 470), (880, 540), (900, 600), (940, PLAY_H)], 16)
    # 저수지
    pygame.draw.polygon(surf, (190, 170, 120), [(230 + (x - 230) * 1.08, 390 + (y - 390) * 1.08) for x, y in res])
    pygame.draw.polygon(surf, (50, 110, 150), res)
    pygame.draw.line(surf, (160, 140, 90), (100, 505), (360, 505), 10)   # 제방
    pygame.draw.line(surf, (200, 190, 150), (100, 500), (360, 500), 2)
    for d in ((180, 380), (290, 420)):
        pygame.draw.rect(surf, (150, 110, 60), (d[0], d[1], 18, 12))  # 좌대
    _houses(surf, rng, 110, 190, 8)
    _houses(surf, rng, 300, 560, 6)
    # 물결
    for poly in (dam, res):
        xs = [p[0] for p in poly]
        ys = [p[1] for p in poly]
        for _ in range(80):
            x, y = rng.uniform(min(xs), max(xs)), rng.uniform(min(ys), max(ys))
            if _point_in_poly(x, y, poly):
                pygame.draw.line(surf, (140, 190, 225), (x, y), (x + rng.randint(3, 8), y), 1)
    if night:
        _night_tint(surf)
    return surf


def build_sea_map(night=False):
    rng = random.Random(23)
    surf = pygame.Surface((SCREEN_W, PLAY_H))
    coast = [(0, 0), (380, 0), (360, 90), (420, 170), (300, 260), (330, 360), (260, 460), (300, 560), (240, PLAY_H), (0, PLAY_H)]
    _land(surf, rng, lambda x, y: not _point_in_poly(x, y, coast))
    # 바다
    sea_poly = [(380, 0), (SCREEN_W, 0), (SCREEN_W, PLAY_H), (240, PLAY_H), (300, 560), (260, 460), (330, 360),
                (300, 260), (420, 170), (360, 90)]
    pygame.draw.polygon(surf, (40, 110, 180), sea_poly)
    vg = pygame.Surface((SCREEN_W, PLAY_H), pygame.SRCALPHA)
    for x in range(0, SCREEN_W, 4):
        a = int(max(0, min(120, (x - 350) / 5)))
        pygame.draw.line(vg, (10, 40, 100, a), (x, 0), (x, PLAY_H))
    surf.blit(vg, (0, 0))
    # 해안선 모래
    pygame.draw.lines(surf, (220, 200, 140), False, coast[1:-1], 10)
    # 갯바위 곶
    for _ in range(26):
        x, y = 420 + rng.randint(-30, 60), 150 + rng.randint(-40, 40)
        c = rng.randint(90, 130)
        pygame.draw.circle(surf, (c, c, c - 5), (x, y), rng.randint(6, 16))
    pygame.draw.circle(surf, (240, 245, 250), (470, 150), 60, 2)
    # 항구와 방파제
    _houses(surf, rng, 170, 330, 12)
    pygame.draw.lines(surf, (220, 220, 215), False, [(320, 380), (420, 400), (500, 360)], 10)
    pygame.draw.circle(surf, (210, 50, 40), (500, 360), 8)
    for bx, by in ((360, 420), (380, 440)):
        pygame.draw.ellipse(surf, (240, 240, 240), (bx, by, 22, 8))
    # 먼바다의 낚싯배
    bx, by = 780, 250
    pygame.draw.lines(surf, (200, 225, 245), False, [(bx - 150, by + 60), (bx - 60, by + 20), (bx - 10, by + 4)], 3)
    pygame.draw.polygon(surf, (240, 240, 240), [(bx - 26, by - 6), (bx + 26, by - 6), (bx + 18, by + 8), (bx - 20, by + 8)])
    pygame.draw.rect(surf, (40, 80, 160), (bx - 8, by - 16, 14, 10))
    # 물결
    for _ in range(300):
        x, y = rng.randint(330, SCREEN_W), rng.randint(0, PLAY_H)
        if _point_in_poly(x, y, sea_poly):
            pygame.draw.arc(surf, (130, 180, 225), (x, y, 14, 6), 0.3, 2.8, 1)
    if night:
        _night_tint(surf)
    return surf


def _night_tint(surf):
    tint = pygame.Surface(surf.get_size())
    tint.fill((80, 90, 140))
    surf.blit(tint, (0, 0), special_flags=pygame.BLEND_MULT)


def _point_in_poly(x, y, poly):
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi:
            inside = not inside
        j = i
    return inside


def region_map(region, night=False):
    if region == "lake":
        return build_lake_map(night)
    if region == "sea":
        return build_sea_map(night)
    return build_map(night)


def map_markers(region):
    if region == "lake":
        return {"E": (620, 110), "F": (170, 300)}
    if region == "sea":
        return {"G": (560, 410), "H": (540, 120), "I": (800, 200)}
    return map_marker_positions()


# ------------------------------------------------------------------ 초릿대 (선상)
def draw_tip_zoom(surface, rect, bend, night, t):
    """선상낚시 초릿대 확대창. bend: 0 ~ 1.5"""
    rect = pygame.Rect(rect)
    old_clip = surface.get_clip()
    surface.set_clip(rect)
    sky = (30, 36, 70) if night else (170, 205, 235)
    vgradient(surface, rect, shade(sky, 1.1), shade(sky, 0.85))
    base = (rect.left + 12, rect.bottom - 10)
    wob = math.sin(t * 2.5) * 0.03
    b = max(0.0, bend) + wob
    tip_x = rect.left + rect.w * 0.8
    tip_y = rect.top + 30 + b * rect.h * 0.55
    ctrl = (rect.left + rect.w * 0.45, rect.top + 40)
    pts = []
    for i in range(21):
        u = i / 20
        x = (1 - u) ** 2 * base[0] + 2 * (1 - u) * u * ctrl[0] + u * u * tip_x
        y = (1 - u) ** 2 * base[1] + 2 * (1 - u) * u * ctrl[1] + u * u * tip_y
        pts.append((x, y))
    for i in range(20):
        col = (230, 60, 40) if i >= 16 else ((70, 50, 40) if not night else (120, 100, 90))
        pygame.draw.line(surface, col, pts[i], pts[i + 1], max(2, 7 - i // 3))
    pygame.draw.line(surface, (240, 240, 240), pts[-1], (pts[-1][0], rect.bottom), 1)
    if night:
        g = pygame.Surface((30, 30), pygame.SRCALPHA)
        pygame.draw.circle(g, (120, 255, 120, 110), (15, 15), 12)
        surface.blit(g, (pts[-1][0] - 15, pts[-1][1] - 15))
    surface.set_clip(old_clip)
