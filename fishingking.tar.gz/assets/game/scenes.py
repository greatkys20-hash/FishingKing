"""타이틀 / 장소 선택 지도 / 낚시 화면."""
import math
import random

import pygame

from . import gfx
from .data import (BAIT_NAMES, CHUM_BAITS, FISH, FISH_BY_ID, FRESH_BAITS, MIX_NAMES, PASTE_SIZE_NAMES, REGIONS,
                   SEA_BAITS, SPOT_BY_KEY)
from .logic import BiteEvent, Fight, Rig, bite_rate, hook_success, pick_fish, roll_size, tide_factor, tide_label
from .panels import (AdjustPanel, BaitPanel, CatchPanel, MessagePanel, QuitPanel, RecordPanel, ShopPanel,
                     SoundPanel, UnlockPanel)
from .settings import GOLD, IS_WEB, MENU_H, PLAY_H, RED, SCREEN_H, SCREEN_W, VERSION, WHITE, WOOD_TEXT
from .ui import Button, text, wood_panel


class Scene:
    def __init__(self, app):
        self.app = app
        self.save = app.save
        self.sounds = app.sounds

    def handle(self, event):
        pass

    def update(self, dt):
        pass

    def draw(self, surface):
        pass


class WaterShimmer:
    """수면 위에서 반짝이며 흐르는 물결."""

    def __init__(self, speed=12.0, night=False):
        self.speed = speed
        self.night = night
        self.items = [self._new(random.uniform(0, SCREEN_W)) for _ in range(70)]

    def _new(self, x=None):
        d = random.uniform(1, 40)
        return [x if x is not None else -40, d, random.uniform(10, 40), random.uniform(0.6, 1.4), random.uniform(0, 6.28)]

    def update(self, dt):
        for it in self.items:
            s = gfx.water_scale(it[1])
            it[0] += self.speed * it[3] * s * dt * 3
            it[4] += dt * 2
            if it[0] > SCREEN_W + 40:
                it[:] = self._new()

    def draw(self, surface):
        for x, d, ln, _, ph in self.items:
            y = gfx.water_y(d)
            s = gfx.water_scale(d)
            a = 0.5 + 0.5 * math.sin(ph)
            if self.night:
                col = gfx.lerp_color((40, 50, 80), (120, 130, 160), a)
            else:
                col = gfx.lerp_color((140, 190, 200), (235, 250, 255), a)
            pygame.draw.line(surface, col, (x, y), (x + ln * s + 4, y), 1 if s < 0.4 else 2)


# ====================================================================== 타이틀
class TitleScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.bg = app.background(SPOT_BY_KEY["B"], False)
        self.water = WaterShimmer()
        self.t = 0.0
        self.confirm_new = False
        self.buttons = []
        self.build()

    def build(self):
        cx = SCREEN_W // 2
        has_save = self.save.exists()
        self.buttons = [
            Button((cx - 120, 380, 240, 56), "이어하기", self.cont, 22, enabled=has_save),
            Button((cx - 120, 450, 240, 56), "정말 새로? (기록 삭제)" if self.confirm_new else "새로 시작", self.new, 20),
        ]
        if not IS_WEB:
            self.buttons.append(Button((cx - 120, 520, 240, 56), "종료", self.quit, 22))

    def cont(self):
        self.save.load()
        self.app.change(FishingScene(self.app))

    def new(self):
        if self.save.exists() and not self.confirm_new:
            self.confirm_new = True
            self.build()
            return
        from .save import SaveData
        self.app.save = SaveData()
        self.app.sounds.settings = self.app.save["sound"]
        self.app.save.save()
        self.app.change(MapScene(self.app, from_fishing=False))

    def quit(self):
        self.app.running = False

    def handle(self, event):
        for b in self.buttons:
            b.handle(event, self.sounds)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
            (self.cont if self.save.exists() else self.new)()

    def update(self, dt):
        self.t += dt
        self.water.update(dt)
        self.sounds.update_ambient(dt, False)

    def draw(self, surface):
        surface.blit(self.bg, (0, 0))
        self.water.draw(surface)
        surface.fill((40, 30, 10), (0, PLAY_H, SCREEN_W, MENU_H))
        # 로고
        bob = math.sin(self.t * 1.5) * 4
        panel = pygame.Rect(SCREEN_W // 2 - 300, 90 + bob, 600, 190)
        wood_panel(surface, panel)
        text(surface, "FishingKing", (SCREEN_W // 2, 160 + bob), 76, GOLD, bold=True, center=True, shadow=(90, 50, 10))
        text(surface, "~ 낚 시 왕 ~  민물·바다 낚시 시뮬레이션", (SCREEN_W // 2, 238 + bob), 22, WOOD_TEXT, bold=True, center=True)
        fish = FISH_BY_ID["carp"]
        gfx.draw_fish(surface, fish, (SCREEN_W // 2 + 330, 190 + bob * 2), 110, facing=-1, angle=20)
        gfx.draw_fish(surface, FISH_BY_ID["crucian"], (SCREEN_W // 2 - 340, 200 - bob * 2), 80, facing=1, angle=-15)
        for b in self.buttons:
            b.draw(surface)
        text(surface, f"v{VERSION}  ·  1994년 타프시스템 '낚시광'에서 영감을 받은 팬메이드 게임",
             (SCREEN_W // 2, SCREEN_H - 28), 15, (230, 210, 160), center=True)


# ====================================================================== 지도
class MapScene(Scene):
    def __init__(self, app, from_fishing=True, region=None):
        super().__init__(app)
        self.from_fishing = from_fishing
        self.night = self.save["night"]
        self.region = region or SPOT_BY_KEY[self.save["spot"]].region
        self.panel = None
        self.flash = ""
        self.flash_t = 0.0
        self.t = 0.0
        self.picked = None          # 터치: 한 번 누르면 선택, 한 번 더 누르면 출발
        self.load_region()

    @property
    def spot(self):
        return SPOT_BY_KEY[self.save["spot"]]

    @property
    def locked(self):
        return self.region not in self.save["unlocked"]

    def load_region(self):
        self.map = self.app.map_surface(self.region, self.night)
        self.markers = gfx.map_markers(self.region)
        self.hover = None
        self.picked = None
        self.buttons = []
        for i, reg in enumerate(REGIONS):
            label = reg["name"] + ("" if reg["id"] in self.save["unlocked"] else " (잠김)")
            self.buttons.append(Button((10 + i * 160, PLAY_H + 6, 152, 44), label,
                                       lambda r=reg["id"]: self.set_region(r), 18, toggled=reg["id"] == self.region))
        if self.from_fishing:
            self.buttons.append(Button((SCREEN_W - 170, PLAY_H + 6, 160, 44), "돌아가기", self.back, 20))

    def set_region(self, region):
        self.region = region
        self.load_region()
        if self.locked:
            self.panel = UnlockPanel(self, region, self.load_region)

    def back(self):
        self.app.change(FishingScene(self.app))

    def choose(self, key):
        if self.locked:
            self.panel = UnlockPanel(self, self.region, self.load_region)
            return
        spot = SPOT_BY_KEY[key]
        if spot.fee:
            if self.save["money"] < spot.fee:
                self.sounds.play("error")
                self.flash, self.flash_t = f"배삯 {spot.fee:,}원이 부족합니다!", 2.5
                return
            self.save["money"] -= spot.fee
            self.sounds.play("coin")
        else:
            self.sounds.play("click")
        self.save["spot"] = key
        self.save.save()
        self.app.change(FishingScene(self.app))

    def handle(self, event):
        if self.panel:
            self.panel.handle(event)
            if self.panel and self.panel.closed:
                self.panel = None
            return
        for b in self.buttons:
            if b.handle(event, self.sounds):
                return
        if event.type == pygame.MOUSEMOTION:
            self.hover = None
            for key, pos in self.markers.items():
                if math.hypot(event.pos[0] - pos[0], event.pos[1] - pos[1]) < 50:
                    self.hover = key
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            hit = None
            for key, pos in self.markers.items():
                if math.hypot(event.pos[0] - pos[0], event.pos[1] - pos[1]) < 55:
                    hit = key
            if hit is None:
                return
            if getattr(event, "touch", False) and self.picked != hit:
                self.picked = self.hover = hit
                self.sounds.play("click")
                return
            self.choose(hit)
        elif event.type == pygame.KEYDOWN:
            name = pygame.key.name(event.key).upper()
            if name in self.markers:
                self.choose(name)
            elif event.key == pygame.K_ESCAPE and self.from_fishing:
                self.back()

    def update(self, dt):
        self.t += dt
        self.flash_t = max(0.0, self.flash_t - dt)
        self.sounds.update_ambient(dt, self.night, self.region == "sea")
        if self.panel:
            self.panel.update(dt)
            if self.panel.closed:
                self.panel = None

    def draw(self, surface):
        surface.blit(self.map, (0, 0))
        if self.locked:
            dim = pygame.Surface((SCREEN_W, PLAY_H), pygame.SRCALPHA)
            dim.fill((0, 0, 0, 110))
            surface.blit(dim, (0, 0))
        for key, pos in self.markers.items():
            bob = math.sin(self.t * 3 + ord(key)) * 3 if key == self.hover else 0
            gfx.draw_map_marker(surface, (pos[0], pos[1] + bob), key, key == self.save["spot"], key == self.hover)
        region_name = next(r["name"] for r in REGIONS if r["id"] == self.region)
        plaque = pygame.Rect(16, 14, 320, 48)
        wood_panel(surface, plaque)
        text(surface, f"장소 선택 - {region_name}" + ("  (밤)" if self.night else "  (낮)"), plaque.center, 21,
             bold=True, center=True)
        key = self.hover or self.picked or (self.save["spot"] if self.save["spot"] in self.markers
                                            else next(iter(self.markers)))
        spot = SPOT_BY_KEY[key]
        info = pygame.Rect(16, PLAY_H - 150, 500, 136)
        wood_panel(surface, info)
        text(surface, spot.name, (info.left + 18, info.top + 12), 22, bold=True)
        extra = f"  ·  배삯 {spot.fee:,}원" if spot.fee else ""
        text(surface, f"수심 약 {spot.bottom:.0f}m{extra}", (info.right - 18, info.top + 16), 17, right=True)
        text(surface, spot.desc, (info.left + 18, info.top + 48), 16)
        seen = [FISH_BY_ID[f].name for f in spot.population if f in self.save["book"]]
        unknown = len(spot.population) - len(seen)
        line = "잡아본 어종: " + (", ".join(seen) if seen else "없음")
        if unknown:
            line += f"  (+ ??? {unknown}종)"
        text(surface, line, (info.left + 18, info.top + 80), 15)
        keys = "/".join(self.markers)
        if self.picked == key:
            text(surface, "한 번 더 누르면 출발!", (info.left + 18, info.top + 104), 16, RED, bold=True)
        else:
            text(surface, f"클릭 또는 {keys} 키로 선택", (info.left + 18, info.top + 106), 14, (110, 80, 40))
        if self.flash_t > 0:
            text(surface, self.flash, (SCREEN_W // 2, 90), 22, RED, bold=True, center=True, shadow=(0, 0, 0))
        surface.fill((60, 40, 15), (0, PLAY_H, SCREEN_W, MENU_H))
        for b in self.buttons:
            b.draw(surface)
        if self.panel:
            dim = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            dim.fill((0, 0, 0, 90))
            surface.blit(dim, (0, 0))
            self.panel.draw(surface)


# ====================================================================== 낚시
MENU = ["음향", "조정", "먹이", "장소", "낮/밤", "상점", "확인", "종료"]
STEER_R = 56
STEER_LEFT = (92, PLAY_H - 100)
STEER_RIGHT = (SCREEN_W - 92, PLAY_H - 100)
FLOAT_X = 430
TIP_X = 640     # 선상: 뱃전 옆으로 줄이 내려가는 위치


class FishingScene(Scene):
    def __init__(self, app):
        super().__init__(app)
        self.spot = SPOT_BY_KEY[self.save["spot"]]
        self.night = self.save["night"]
        self.bg = app.background(self.spot, self.night)
        self.tip = self.spot.style == "tip"
        speed = 28 if self.spot.feature == "rapids" else (18 if self.spot.sea else 10)
        self.water = WaterShimmer(speed, self.night)
        valid = SEA_BAITS if self.spot.sea else FRESH_BAITS
        if self.save.bait_for(self.spot) not in valid:
            self.save.set_bait(self.spot, valid[0])
        self.settle_dur = 1.2
        self.foam_timer = 1.0
        self.tide_offset = random.uniform(0, 240)
        self.use_touch = IS_WEB
        self.fingers = {}           # 손가락 id -> "reel" / "left" / "right"
        self.mouse_steer = 0
        self.state = "ready"
        self.power = 0.0
        self.power_dir = 1
        self.cast_dist = 8.0
        self.float_x = FLOAT_X
        self.float_offset = 0.0
        self.fly_t = 0.0
        self.settle_t = 0.0
        self.hook_bait = None
        self.paste_left = 0.0
        self.paste_time = 1.0
        self.chum = 0.0
        self.last_cast = -99.0
        self.bite = None
        self.fight = None
        self.rig = Rig(self.save, self.spot)
        self.ripples = []
        self.bubbles = []
        self.bubble_timer = 3.0
        self.splashes = []
        self.message = ""
        self.msg_t = 0.0
        self.msg_color = WHITE
        self.panel = None
        self.holding = False
        self.reel_t = 0.0
        self.t = 0.0
        self.warned_dissolve = False
        self.warn_t = 0.0
        self.menu_buttons = []
        w = SCREEN_W // len(MENU)
        actions = [self.open_sound, self.open_adjust, self.open_bait, self.open_map, self.toggle_night,
                   self.open_shop, self.open_record, self.open_quit]
        for i, (label, fn) in enumerate(zip(MENU, actions)):
            self.menu_buttons.append(Button((i * w + 2, PLAY_H + 4, w - 4, MENU_H - 8), label, fn, 20, tag=label))
        if not self.save.data.get("tutorial"):
            self.save["tutorial"] = True
            if IS_WEB:
                guide = ("1. [먹이]에서 미끼를 고르고, [조정]에서 찌 높이를 맞춥니다.\n"
                         "2. 화면을 누르고 있다가 떼면 캐스팅!\n"
                         "3. 찌가 쭉 올라오거나 잠길 때 화면을 눌러 챔질.\n"
                         "4. 화면을 누르고 있으면 릴 감기, 장력이 빨개지면 손을 떼세요.\n"
                         "    다른 손가락으로 ◀ ▶ 버튼을 눌러 낚싯대를 기울이세요.")
            else:
                guide = ("1. [먹이]에서 미끼를 고르고, [조정]에서 찌 높이를 맞춥니다.\n"
                         "2. 스페이스(또는 마우스)를 누르고 있다가 떼면 캐스팅!\n"
                         "3. 찌가 쭉 올라오거나 잠길 때 스페이스로 챔질.\n"
                         "4. 스페이스를 누르면 릴 감기, 장력이 빨개지면 손을 떼세요.\n"
                         "    ←/→ 키로 고기 반대쪽으로 낚싯대를 기울이면 유리합니다.")
            self.panel = MessagePanel(self, "FishingKing 조작법", guide)
            self.panel.rect.h = 330
            self.panel.rect.centery = PLAY_H // 2
            self.panel.rebuild()

    # ------------------------------------------------------------ 메뉴
    def _line_busy(self):
        return self.state in ("bite", "fight", "result", "flying")

    def _retrieve_for_menu(self):
        if self._line_busy():
            self.say("지금은 낚시에 집중하세요!", RED)
            self.sounds.play("error")
            return False
        if self.state in ("waiting", "settling", "charging"):
            self.state = "ready"
            self.say("채비를 회수했습니다.")
        return True

    def open_sound(self):
        self.panel = SoundPanel(self)

    def open_adjust(self):
        if self._retrieve_for_menu():
            self.panel = AdjustPanel(self)

    def open_bait(self):
        if self._retrieve_for_menu():
            self.panel = BaitPanel(self)

    def open_shop(self):
        if self._retrieve_for_menu():
            self.panel = ShopPanel(self)

    def open_record(self):
        self.panel = RecordPanel(self)

    def open_quit(self):
        self.panel = QuitPanel(self)

    def open_map(self):
        if self._retrieve_for_menu():
            self.save.save()
            self.app.change(MapScene(self.app))

    def toggle_night(self):
        if not self._retrieve_for_menu():
            return
        self.night = not self.night
        self.save["night"] = self.night
        self.bg = self.app.background(self.spot, self.night)
        self.water.night = self.night
        self.say("밤이 되었습니다. 야행성 고기가 움직입니다." if self.night else "아침이 밝았습니다.")
        self.save.save()

    # ------------------------------------------------------------ 도우미
    def say(self, msg, color=WHITE, dur=3.0):
        self.message, self.msg_color, self.msg_t = msg, color, dur

    def float_pos(self):
        return self.float_x, gfx.water_y(self.cast_dist)

    def add_ripple(self, x, y, scale, big=False):
        self.ripples.append([x, y, 4.0, 200 if big else 140, scale, 40 if big else 25])

    def check_bait(self):
        bait = self.save.bait_for(self.spot)
        stock = self.save["stock"]
        if bait == "paste" and sum(self.save["mix"]) == 0:
            self.say("떡밥 배합이 비어 있습니다. [먹이]에서 재료를 넣어주세요.", RED)
            return False
        if bait in CHUM_BAITS:
            if stock[bait] <= 0:
                self.say(f"{BAIT_NAMES[bait]}이(가) 떨어졌습니다. [상점]에서 사거나 다른 미끼를 쓰세요.", RED)
                return False
        elif self.hook_bait != bait and stock[bait] <= 0:
            self.say(f"{BAIT_NAMES[bait]}이(가) 없습니다. [상점]에서 구입하세요.", RED)
            return False
        return True

    def lose_bait(self):
        self.hook_bait = None

    # ------------------------------------------------------------ 입력
    def handle(self, event):
        if event.type == pygame.FINGERUP and self.panel:
            self.fingers.pop(event.finger_id, None)     # 패널이 떠 있어도 손가락 상태는 정리
            self.holding = False
            return
        if self.panel:
            self.panel.handle(event)
            if self.panel and self.panel.closed:
                self.panel = None
            return
        if event.type in (pygame.FINGERDOWN, pygame.FINGERUP):
            self.handle_finger(event)
            return
        for b in self.menu_buttons:
            if b.handle(event, self.sounds):
                return
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP) and getattr(event, "touch", False) \
                and self.use_touch:
            return      # 터치로 만들어진 마우스 이벤트는 FINGER 이벤트에서 처리
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                self.press()
            elif event.key == pygame.K_ESCAPE:
                self.open_quit()
            elif pygame.K_1 <= event.key <= pygame.K_8:
                btn = self.menu_buttons[event.key - pygame.K_1]
                if btn.enabled:
                    self.sounds.play("click")
                    btn.callback()
        elif event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
            self.release()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and event.pos[1] < PLAY_H:
            steer = self.steer_at(event.pos)
            if steer:
                self.mouse_steer = steer
            else:
                self.press()
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.mouse_steer:
                self.mouse_steer = 0
            else:
                self.release()

    def steer_at(self, pos):
        """파이팅 중 화면의 ◀ ▶ 버튼 위치면 -1 / 1."""
        if self.state != "fight":
            return 0
        for c, v in ((STEER_LEFT, -1), (STEER_RIGHT, 1)):
            if math.hypot(pos[0] - c[0], pos[1] - c[1]) <= STEER_R + 10:
                return v
        return 0

    def handle_finger(self, event):
        """멀티터치: 한 손가락은 릴 감기, 다른 손가락은 ◀ ▶."""
        self.use_touch = True
        pos = (event.x * SCREEN_W, event.y * SCREEN_H)
        if event.type == pygame.FINGERDOWN:
            if pos[1] >= PLAY_H:
                return      # 메뉴바는 마우스 이벤트로 처리
            steer = self.steer_at(pos)
            if steer:
                self.fingers[event.finger_id] = "left" if steer < 0 else "right"
            else:
                self.fingers[event.finger_id] = "reel"
                self.press()
        else:
            role = self.fingers.pop(event.finger_id, None)
            if role == "reel" and "reel" not in self.fingers.values():
                self.release()

    def press(self):
        s = self.state
        if s == "ready":
            if self.check_bait():
                if self.tip:
                    self.power = 0.0
                    self.cast()
                else:
                    self.state = "charging"
                    self.power, self.power_dir = 0.0, 1
        elif s in ("waiting", "settling"):
            self.state = "ready"
            self.sounds.play("plop")
            self.say("채비를 회수했습니다.")
        elif s == "bite":
            self.strike()
        elif s == "fight":
            self.holding = True

    def release(self):
        self.holding = False
        if self.state == "charging":
            self.cast()

    def cast(self):
        self.rig = Rig(self.save, self.spot)
        bait = self.save.bait_for(self.spot)
        stock = self.save["stock"]
        if self.hook_bait and self.hook_bait not in CHUM_BAITS and self.hook_bait != bait:
            stock[self.hook_bait] += 1          # 끼워둔 미끼는 통에 돌려놓는다
            self.hook_bait = None
        if bait in CHUM_BAITS:
            stock[bait] -= 1
            self.hook_bait = bait
            if bait == "paste":
                mix = self.save["mix"]
                wj = mix[1] / max(1, sum(mix))
                self.paste_time = 50 * (0.8 + 0.3 * self.save["paste_size"]) * (1.2 - 0.5 * wj)
            else:
                self.paste_time = 40.0
            self.paste_left = 1.0
        elif self.hook_bait != bait:
            stock[bait] -= 1
            self.hook_bait = bait
        if self.tip:
            self.cast_dist = 2.5
            self.float_x = TIP_X
        else:
            self.cast_dist = 3 + self.power * (self.rig.rod["cast"] - 3)
            self.float_x = FLOAT_X + random.randint(-30, 30)
        self.state = "flying"
        self.fly_t = 0.0
        self.warned_dissolve = False
        self.sounds.play("cast")

    def land_float(self):
        x, y = self.float_pos()
        self.add_ripple(x, y, gfx.water_scale(self.cast_dist), big=True)
        self.sounds.play("splash")
        if self.hook_bait in CHUM_BAITS:
            if abs(self.cast_dist - self.last_cast) < 2.5:
                self.chum = min(1.5, self.chum + 0.25)
            else:
                self.chum = self.chum * 0.3 + 0.1
        self.last_cast = self.cast_dist
        self.state = "settling"
        self.settle_t = 0.0
        self.settle_dur = max(1.2, self.rig.bait_depth / 8) if self.tip else 1.2
        if self.rig.float_lying:
            self.say("찌가 누웠습니다. [조정]에서 찌 높이를 수심보다 얕게 해보세요.", GOLD, 4)

    def strike(self):
        bite = self.bite
        rig = self.rig
        if bite.kind != "main":
            self.state = "ready"
            self.sounds.play("hook")
            self.say("헛챔질! 예신에 너무 일찍 챘습니다.", GOLD)
            if self.hook_bait not in CHUM_BAITS and random.random() < 0.4:
                self.lose_bait()
            return
        fish = bite.fish
        if random.random() < hook_success(fish, rig):
            t, length, weight, price = roll_size(fish, rig)
            start = rig.bait_depth + 3 if self.tip else self.cast_dist
            self.fight = Fight(fish, t, length, weight, rig, start)
            self.fight.price = price
            self.state = "fight"
            self.holding = True
            self.sounds.play("hook")
            self.say("걸었다!", GOLD, 1.5)
        else:
            self.state = "ready"
            self.sounds.play("escape")
            extra = " (바늘이 너무 큰가?)" if rig.hook["size"] > fish.mouth else ""
            self.say("바늘이 걸리지 않았다..." + extra, GOLD)
            if self.hook_bait not in CHUM_BAITS:
                self.lose_bait()

    # ------------------------------------------------------------ 갱신
    def update(self, dt):
        self.t += dt
        self.water.update(dt)
        self.sounds.update_ambient(dt, self.night, self.spot.sea)
        self.msg_t = max(0.0, self.msg_t - dt)
        self.update_foam(dt)
        for r in self.ripples:
            r[2] += r[5] * dt
            r[3] -= 110 * dt
        self.ripples = [r for r in self.ripples if r[3] > 0]
        for b in self.bubbles:
            b[3] -= dt
        self.bubbles = [b for b in self.bubbles if b[3] > 0]
        for s in self.splashes:
            s[4] -= dt
            s[0] += s[2] * dt
            s[1] += s[3] * dt
            s[3] += 400 * dt
        self.splashes = [s for s in self.splashes if s[4] > 0]
        for b in self.menu_buttons:
            b.enabled = not (self._line_busy() and b.tag not in ("음향", "확인"))

        if self.panel:
            self.panel.update(dt)
            if self.panel.closed:
                self.panel = None
            return

        self.update_bubbles(dt)
        s = self.state
        if s == "charging":
            self.power += self.power_dir * dt * 0.9
            if self.power >= 1:
                self.power, self.power_dir = 1.0, -1
            elif self.power <= 0:
                self.power, self.power_dir = 0.0, 1
        elif s == "flying":
            self.fly_t += dt / 0.7
            if self.fly_t >= 1:
                self.land_float()
        elif s == "settling":
            self.settle_t += dt
            self.float_offset = -1 + min(1.0, self.settle_t / self.settle_dur)
            if self.settle_t >= self.settle_dur:
                self.state = "waiting"
                self.float_offset = 0.0
        elif s == "waiting":
            self.update_waiting(dt)
        elif s == "bite":
            self.update_bite(dt)
        elif s == "fight":
            self.update_fight(dt)

    def update_foam(self, dt):
        """갯바위·방파제에 부서지는 파도."""
        if self.spot.feature not in ("rocks", "breakwater"):
            return
        self.foam_timer -= dt
        if self.foam_timer <= 0:
            self.foam_timer = random.uniform(1.5, 4.0)
            if self.spot.feature == "rocks":
                x, y = random.choice([(random.randint(40, 200), PLAY_H - 175), (random.randint(760, 920), PLAY_H - 190),
                                      (random.randint(780, 960), int(gfx.water_y(12)) - 30)])
            else:
                x = SCREEN_W // 2 + random.choice([-1, 1]) * random.randint(280, 480)
                y = PLAY_H - random.randint(120, 190)
            self.spawn_splash(x, y, 1.1, 16)
            if random.random() < 0.5:
                self.sounds.play("splash")

    def tide(self):
        return tide_factor(self.t + self.tide_offset) if self.spot.sea else 1.0

    def bait_level(self):
        if self.hook_bait in CHUM_BAITS:
            return 0.15 + 0.85 * self.paste_left
        return 1.0 if self.hook_bait else 0.03

    def update_waiting(self, dt):
        self.float_offset = math.sin(self.t * 1.7) * 0.04
        self.chum = max(0.0, self.chum - 0.004 * dt)
        if self.hook_bait in CHUM_BAITS:
            self.paste_left = max(0.0, self.paste_left - dt / self.paste_time)
            if self.paste_left <= 0 and not self.warned_dissolve:
                self.warned_dissolve = True
                if self.hook_bait == "paste":
                    self.say("떡밥이 다 풀린 것 같다. 다시 던져보자.")
                else:
                    self.say("크릴이 떨어져 나간 것 같다. 다시 던져보자.")
        rate = bite_rate(self.rig, self.cast_dist, self.chum, self.bait_level(), self.tide())
        if random.random() < rate * dt:
            self.bite = BiteEvent(pick_fish(self.rig), self.rig)
            self.state = "bite"

    def update_bite(self, dt):
        changed = self.bite.update(dt)
        x, y = self.float_pos()
        sc = gfx.water_scale(self.cast_dist)
        if changed == "nibble":
            self.sounds.play("nibble")
            self.add_ripple(x, y, sc)
        elif changed == "main":
            self.sounds.play("plop")
            self.add_ripple(x, y, sc, big=True)
        elif changed == "done":
            self.state = "waiting"
            self.float_offset = 0.0
            if self.hook_bait in CHUM_BAITS:
                self.paste_left *= 0.5
                self.say("입질을 놓쳤다...")
            else:
                self.lose_bait()
                self.say("미끼만 따먹혔다! 다시 던져야 한다.", GOLD)
            return
        self.float_offset = self.bite.float_offset(self.rig.float_lying) + math.sin(self.t * 1.7) * 0.03

    def update_fight(self, dt):
        f = self.fight
        keys = pygame.key.get_pressed()
        steer = (1 if keys[pygame.K_RIGHT] or keys[pygame.K_d] else 0) - (1 if keys[pygame.K_LEFT] or keys[pygame.K_a] else 0)
        roles = set(self.fingers.values())
        steer += ("right" in roles) - ("left" in roles) + self.mouse_steer
        steer = max(-1, min(1, steer))
        self.steer_now = steer
        reeling = self.holding or keys[pygame.K_SPACE]
        was_jump = f.jump
        was_running = f.running
        f.update(dt, reeling, steer)
        ex, ey = self.entry_point()
        sc = gfx.water_scale(f.distance)
        if reeling:
            self.reel_t -= dt
            if self.reel_t <= 0:
                self.reel_t = 0.09
                self.sounds.play("reel")
        if f.jump > 0 and was_jump <= 0:
            self.sounds.play("jump")
            self.spawn_splash(ex, ey, sc, 14)
        if f.running and not was_running:
            self.add_ripple(ex, ey, sc, big=True)
        if random.random() < (6 if f.running else 1.5) * dt:
            self.add_ripple(ex + random.randint(-8, 8), ey, sc)
        if f.tension_ratio > 0.85:
            self.warn_t -= dt
            if self.warn_t <= 0:
                self.warn_t = 0.35
                self.sounds.play("nibble")
        if f.result:
            self.finish_fight(f.result)

    def finish_fight(self, result):
        f = self.fight
        self.lose_bait()
        self.holding = False
        if result == "landed":
            self.state = "result"
            record = self.save.record_catch(f.fish, f.length, f.weight)
            self.sounds.play("record" if record else "catch")
            ex, ey = self.entry_point()
            self.spawn_splash(ex, ey, 1.0, 20)
            self.panel = CatchPanel(self, f.fish, f.length, f.weight, f.price, record, self.after_catch)
            self.save.save()
            return
        self.state = "ready"
        msgs = {"snap": ("팅! 줄이 끊어졌다! 장력이 빨개지면 손을 떼세요.", "snap"),
                "spooled": ("줄이 다 풀려 끊어졌다!", "snap"),
                "unhook": ("바늘이 빠졌다... 놓쳤다!", "escape"),
                "net_miss": ("뜰채가 없어 건지다 놓쳤다! [상점]에서 뜰채를 사세요.", "escape")}
        msg, snd = msgs[result]
        self.sounds.play(snd)
        self.say(msg, RED, 4)
        self.fight = None

    def after_catch(self):
        self.state = "ready"
        self.fight = None
        if not self.save.data.get("king") and all(f.id in self.save["book"] for f in FISH):
            self.save["king"] = True
            self.save.save()
            self.sounds.play("record")
            self.panel = MessagePanel(self, "★ 축하합니다 ★",
                                      "모든 어종을 낚아 도감을 완성했습니다!\n당신이야말로 진정한 FishingKing!")

    def update_bubbles(self, dt):
        if self.tip:
            return
        self.bubble_timer -= dt
        if self.bubble_timer <= 0:
            self.bubble_timer = random.uniform(3, 8) / (1 + self.chum)
            d = self.spot.hot + random.uniform(-2, 2)
            x = FLOAT_X + random.randint(-160, 160)
            for _ in range(random.randint(2, 5)):
                self.bubbles.append([x + random.randint(-10, 10), d + random.uniform(-0.4, 0.4),
                                     random.uniform(1.5, 3.5), random.uniform(0.6, 1.8)])

    def spawn_splash(self, x, y, scale, n):
        for _ in range(n):
            self.splashes.append([x, y, random.uniform(-80, 80) * scale, random.uniform(-260, -120) * scale,
                                  random.uniform(0.4, 0.8), max(2, int(4 * scale))])

    def entry_point(self):
        f = self.fight
        if self.tip:
            return TIP_X + f.x * 140, gfx.water_y(2.5)
        x = max(60, min(SCREEN_W - 60, FLOAT_X + f.x * 330))
        return x, gfx.water_y(f.distance)

    # ------------------------------------------------------------ 그리기
    def draw(self, surface):
        surface.blit(self.bg, (0, 0))
        self.water.draw(surface)
        for x, d, r, life in self.bubbles:
            y = gfx.water_y(d)
            sc = gfx.water_scale(d)
            rr = max(1, int(r * sc * 1.5))
            pygame.draw.circle(surface, (220, 240, 245), (int(x), int(y - (1.8 - life) * 3)), rr, 1)
        for x, y, r, a, sc, _ in self.ripples:
            gfx.draw_ripple(surface, x, y, r, a, sc)

        tip = gfx.ROD_TIP
        bend = 0.0
        lean = 0.0
        s = self.state
        line_col = (235, 235, 235) if not self.night else (140, 140, 160)
        if s == "fight" and self.fight:
            f = self.fight
            ex, ey = self.entry_point()
            bend = min(1.0, f.tension / 6.0 + 0.15)
            lean = f.x
            tip = gfx.rod_tip_for(bend, ex)
            if f.distance < 6:
                self.draw_underwater_fish(surface, ex, ey)
            if f.jump > 0:
                h = math.sin(f.jump / 0.8 * math.pi) * 90 * gfx.water_scale(f.distance) + 10
                px = f.length * 1.4 * gfx.water_scale(f.distance) + 10
                gfx.draw_fish(surface, f.fish, (ex, ey - h), px, facing=1 if f.target_x > f.x else -1,
                              angle=(f.jump - 0.4) * 60)
            pygame.draw.line(surface, line_col, tip, (ex, ey), 1)
        elif s in ("waiting", "settling", "bite") and self.tip:
            x, y = self.float_pos()
            bend = self.tip_bend()
            tip = gfx.rod_tip_for(bend, x)
            pygame.draw.line(surface, line_col, tip, (x, y), 1)
        elif s in ("waiting", "settling", "bite"):
            x, y = self.float_pos()
            self.draw_line_sag(surface, tip, (x, y - 10), line_col)
            self.draw_float(surface, x, y)
        elif s == "flying":
            x1, y1 = tip
            x2, y2 = self.float_pos()
            t = self.fly_t
            fx = gfx.lerp(x1, x2, t)
            fy = gfx.lerp(y1, y2, t) - math.sin(t * math.pi) * 120
            pygame.draw.line(surface, line_col, tip, (fx, fy), 1)
            gfx.draw_float(surface, int(fx), int(fy) + 20, 0.5, 0.2, night=self.night)
        else:
            hang = (tip[0] + 4, tip[1] + 120)
            pygame.draw.line(surface, line_col, tip, hang, 1)
            if self.tip:
                pygame.draw.circle(surface, (90, 90, 95), (hang[0], hang[1] + 6), 6)   # 봉돌
            else:
                gfx.draw_float(surface, hang[0], hang[1] + 40, 0.5, 0.2, night=self.night)
        for x, y, vx, vy, life, r in self.splashes:
            pygame.draw.circle(surface, (235, 245, 250), (int(x), int(y)), r)

        gfx.draw_angler(surface, self.night, lean)
        gfx.draw_rod(surface, tip, bend, lean, self.night)

        self.draw_hud(surface)
        if s in ("waiting", "settling", "bite"):
            zr = pygame.Rect(22, PLAY_H - 262, 140, 200)
            wood_panel(surface, zr.inflate(16, 44).move(0, -12), screws=False)
            if self.tip:
                text(surface, "초릿대", (zr.centerx, zr.top - 20), 15, bold=True, center=True)
                gfx.draw_tip_zoom(surface, zr, self.tip_bend() if s != "settling" else 0.0, self.night, self.t)
            else:
                text(surface, "찌 확대", (zr.centerx, zr.top - 20), 15, bold=True, center=True)
                gfx.draw_float_zoom(surface, zr, self.float_offset, self.rig.float_lying and s != "settling",
                                    self.night, self.night and self.rig.lantern, self.spot.water, self.t)
            pygame.draw.rect(surface, (90, 70, 30), zr, 2)
        if s == "charging":
            self.draw_power(surface)
        if s == "fight" and self.fight:
            self.draw_fight_hud(surface)
            self.draw_steer_buttons(surface)
        self.draw_menu(surface)
        if self.msg_t > 0 and self.message:
            self.draw_message(surface)
        if self.panel:
            dim = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
            dim.fill((0, 0, 0, 90))
            surface.blit(dim, (0, 0))
            self.panel.draw(surface)

    def tip_bend(self):
        """선상: 입질에 따라 초릿대가 휘는 정도."""
        if self.state != "bite":
            return 0.05
        return min(1.3, 0.05 + abs(self.float_offset) * 0.7)

    def draw_line_sag(self, surface, a, b, col):
        pts = []
        for i in range(13):
            t = i / 12
            x = gfx.lerp(a[0], b[0], t)
            y = gfx.lerp(a[1], b[1], t) + math.sin(t * math.pi) * 25
            pts.append((x, y))
        pygame.draw.lines(surface, col, False, pts, 1)

    def draw_float(self, surface, x, y):
        sc = gfx.water_scale(self.cast_dist)
        glow = self.night and self.rig.lantern
        if self.rig.float_lying and self.state != "settling":
            # 누운 찌
            ln = int(70 * sc + 10)
            dy = int(-self.float_offset * 4)
            col = (230, 40, 30) if not self.night or glow else (80, 30, 30)
            pygame.draw.line(surface, col, (x - ln // 2, y + dy), (x + ln // 2, y + dy - 2), max(2, int(4 * sc + 1)))
            return
        gfx.draw_float(surface, x, int(y), sc, self.float_offset, glow=glow, night=self.night)

    def draw_underwater_fish(self, surface, x, y):
        f = self.fight
        sc = gfx.water_scale(f.distance)
        px = f.length * 1.6 * sc + 10
        tmp = pygame.Surface((int(px) + 60, int(px) + 60), pygame.SRCALPHA)
        gfx.draw_fish(tmp, f.fish, (tmp.get_width() // 2, tmp.get_height() // 2), px,
                      facing=1 if f.target_x > f.x else -1, silhouette=True)
        tmp.set_alpha(int(150 * (1 - f.distance / 6)))
        surface.blit(tmp, (x - tmp.get_width() // 2, y + 6 - tmp.get_height() // 2 + 10))

    def draw_hud(self, surface):
        left = pygame.Rect(12, 10, 340 if self.spot.sea else 300, 68)
        wood_panel(surface, left)
        head = f"{self.spot.name}  ·  {'밤' if self.night else '낮'}"
        if self.spot.sea:
            head += f"  ·  {tide_label(self.t + self.tide_offset)}"
        text(surface, head, (left.left + 16, left.top + 9), 17 if self.spot.sea else 18, bold=True)
        text(surface, f"소지금 {self.save['money']:,}원", (left.left + 16, left.top + 38), 17, (120, 60, 0), bold=True)

        right = pygame.Rect(SCREEN_W - 352, 10, 340, 68)
        wood_panel(surface, right)
        bait = self.save.bait_for(self.spot)
        stock = self.save["stock"][bait]
        if bait == "paste":
            mix = self.save["mix"]
            b = f"떡밥({PASTE_SIZE_NAMES[self.save['paste_size']]}) " + ":".join(f"{MIX_NAMES[i][0]}{mix[i]}" for i in range(3))
        else:
            b = BAIT_NAMES[bait]
        text(surface, f"{b}  · 남은 {stock}", (right.left + 16, right.top + 9), 16, bold=True)
        depth = self.save.depth_for(self.spot)
        lying = not self.tip and depth > self.spot.bottom + 0.3
        label = "채비" if self.tip else "찌"
        text(surface, f"{label} {depth:.1f}m / 수심 {self.spot.bottom:.1f}m" + ("  (찌 누움)" if lying else ""),
             (right.left + 16, right.top + 38), 15, RED if lying else WOOD_TEXT)

        hints = {
            "ready": "스페이스(또는 마우스)를 누르고 있다가 떼면 캐스팅!",
            "charging": "적당한 힘에서 손을 떼세요!",
            "flying": "",
            "settling": "찌가 서는 중...",
            "waiting": "찌를 잘 보세요. 쭉 올라오거나 잠길 때 스페이스! (지금 누르면 회수)",
            "bite": "입질이다!? 본신에 챔질!",
            "fight": "스페이스 누르기: 릴 감기  ·  ←/→: 낚싯대 기울이기  ·  빨간 장력은 위험!",
            "result": "",
        }
        if self.tip:
            hints["ready"] = "스페이스(또는 마우스)를 누르면 채비를 내립니다."
            hints["settling"] = f"채비 내리는 중... {self.rig.bait_depth * min(1.0, self.settle_t / self.settle_dur):.0f}m"
            hints["waiting"] = "초릿대를 잘 보세요. 쿡 처박힐 때 스페이스! (지금 누르면 회수)"
        h = hints.get(self.state, "")
        if self.use_touch:
            h = (h.replace("스페이스(또는 마우스)를 누르고", "화면을 누르고").replace("스페이스(또는 마우스)를 누르면", "화면을 누르면")
                 .replace("스페이스 누르기", "화면 누르기").replace("←/→", "◀ ▶").replace("스페이스", "터치"))
        if h and not self.panel:
            text(surface, h, (SCREEN_W // 2, PLAY_H - 18), 16, WHITE, bold=True, center=True, shadow=(0, 0, 0))

    def draw_power(self, surface):
        r = pygame.Rect(740, 360, 34, 220)
        wood_panel(surface, r.inflate(16, 50), screws=False)
        pygame.draw.rect(surface, (40, 40, 40), r)
        fill = int(r.h * self.power)
        col = gfx.lerp_color((60, 200, 60), (230, 60, 30), self.power)
        pygame.draw.rect(surface, col, (r.left, r.bottom - fill, r.w, fill))
        pygame.draw.rect(surface, (20, 20, 20), r, 2)
        dist = 3 + self.power * (Rig(self.save, self.spot).rod["cast"] - 3)
        text(surface, f"{dist:.0f}m", (r.centerx, r.top - 16), 16, bold=True, center=True)
        text(surface, "힘", (r.centerx, r.bottom + 14), 15, bold=True, center=True)

    def draw_fight_hud(self, surface):
        f = self.fight
        r = pygame.Rect(SCREEN_W - 70, 140, 36, 320)
        wood_panel(surface, r.inflate(24, 70), screws=False)
        pygame.draw.rect(surface, (30, 30, 30), r)
        ratio = min(1.0, f.tension_ratio)
        fill = int(r.h * ratio)
        col = (60, 190, 60) if ratio < 0.6 else ((230, 190, 40) if ratio < 0.85 else (220, 40, 30))
        if ratio >= 0.85 and int(self.t * 8) % 2:
            col = (255, 120, 90)
        pygame.draw.rect(surface, col, (r.left, r.bottom - fill, r.w, fill))
        for k in (0.6, 0.85):
            y = r.bottom - int(r.h * k)
            pygame.draw.line(surface, (200, 200, 200), (r.left, y), (r.right, y), 1)
        pygame.draw.rect(surface, (15, 15, 15), r, 2)
        text(surface, "장력", (r.centerx, r.top - 22), 16, bold=True, center=True)
        text(surface, f"{f.distance:.1f}m", (r.centerx, r.bottom + 18), 15, bold=True, center=True)
        # 방향 표시
        arrow_y = 100
        ax = SCREEN_W // 2 + int(f.x * 150)
        pygame.draw.polygon(surface, WHITE, [(ax, arrow_y + 10), (ax - 8, arrow_y - 4), (ax + 8, arrow_y - 4)])
        text(surface, "고기 방향", (SCREEN_W // 2, arrow_y - 18), 14, WHITE, center=True, shadow=(0, 0, 0))
        if f.running:
            text(surface, "차고 나간다!", (SCREEN_W // 2, 130), 22, (255, 220, 120), bold=True, center=True, shadow=(0, 0, 0))

    def draw_steer_buttons(self, surface):
        steer = getattr(self, "steer_now", 0)
        for c, v, label in ((STEER_LEFT, -1, "◀"), (STEER_RIGHT, 1, "▶")):
            active = steer == v
            btn = pygame.Surface((STEER_R * 2 + 4, STEER_R * 2 + 4), pygame.SRCALPHA)
            pygame.draw.circle(btn, (255, 220, 120, 200) if active else (240, 225, 180, 120), (STEER_R + 2, STEER_R + 2), STEER_R)
            pygame.draw.circle(btn, (90, 60, 20, 220), (STEER_R + 2, STEER_R + 2), STEER_R, 3)
            surface.blit(btn, (c[0] - STEER_R - 2, c[1] - STEER_R - 2))
            text(surface, label, c, 40, WOOD_TEXT, bold=True, center=True)

    def draw_menu(self, surface):
        surface.fill((60, 40, 15), (0, PLAY_H, SCREEN_W, MENU_H))
        for b in self.menu_buttons:
            b.draw(surface)

    def draw_message(self, surface):
        alpha = min(1.0, self.msg_t / 0.5)
        img = pygame.Surface((SCREEN_W, 44), pygame.SRCALPHA)
        img.fill((0, 0, 0, int(140 * alpha)))
        surface.blit(img, (0, 176))
        text(surface, self.message, (SCREEN_W // 2, 198), 20, self.msg_color, bold=True, center=True, shadow=(0, 0, 0))

