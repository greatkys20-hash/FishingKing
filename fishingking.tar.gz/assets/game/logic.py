"""낚시 규칙: 입질 확률, 어종/크기 결정, 파이팅 시뮬레이션."""
import math
import random

from .data import FISH_BY_ID, HOOKS, LINES, RODS, find_item


class Rig:
    """현재 채비 상태 (세이브에서 읽어온 값)."""

    def __init__(self, save, spot):
        self.spot = spot
        self.bait = save.bait_for(spot)
        self.paste_size = save["paste_size"]
        self.mix = list(save["mix"])
        self.float_depth = save.depth_for(spot)
        self.night = save["night"]
        self.rod = find_item(RODS, save["rod"])
        self.line = find_item(LINES, save["line"])
        self.hook = find_item(HOOKS, save["hook"])
        self.net = "net" in save["owned"]
        self.lantern = "lantern" in save["owned"]
        self.tip = spot.style == "tip"

    @property
    def bait_depth(self):
        return min(self.float_depth, self.spot.bottom)

    @property
    def float_lying(self):
        """찌 높이가 수심보다 한참 깊으면 찌가 눕는다."""
        return not self.tip and self.float_depth > self.spot.bottom + 0.3


def _mix_match(mix, ideal):
    total = sum(mix)
    if total <= 0:
        return 0.0
    a = [m / total for m in mix]
    dist = math.sqrt(sum((x - y) ** 2 for x, y in zip(a, ideal)))
    return max(0.0, 1.0 - dist / 1.0)


def depth_mult(fish, rig):
    bottom = rig.spot.bottom
    d = rig.bait_depth
    if fish.depth == "bottom":
        gap = bottom - d
        return 1.2 if gap <= 0.15 else 0.1 + 1.1 * math.exp(-gap / (0.35 + 0.05 * bottom))
    if fish.depth == "mid":
        target = bottom * 0.55
        return 0.15 + 1.05 * math.exp(-((d - target) / (0.35 * bottom + 0.2)) ** 2)
    target = min(0.5, bottom * 0.4)
    return 0.1 + 1.1 * math.exp(-((d - target) / (0.6 + 0.1 * bottom)) ** 2)


def preference(fish, rig):
    """해당 채비에 대한 어종의 선호도 (0 ~ 약 2.5)."""
    m = fish.baits.get(rig.bait, 0.0)
    if rig.bait == "paste":
        match = _mix_match(rig.mix, fish.mix)
        m *= 0.3 + 1.2 * match ** 2
        m *= [1.0, 0.6, 0.25][abs(rig.paste_size - fish.size_pref)]
    m *= depth_mult(fish, rig)
    m *= fish.night if rig.night else fish.day
    return m


def distance_mult(distance, spot):
    if spot.style == "tip":
        return 1.0
    return 0.4 + 0.9 * math.exp(-((distance - spot.hot) / 5.0) ** 2)


TIDE_PERIOD = 240.0   # 게임 속 물때 한 주기(초)


def tide_factor(t):
    """바다: 물이 움직일 때(들물/날물) 잘 물고, 정조(만조/간조) 때는 뜸하다."""
    return 0.45 + 0.85 * abs(math.sin(2 * math.pi * t / TIDE_PERIOD))


def tide_label(t):
    phase = (t / TIDE_PERIOD) % 1.0
    if abs(math.sin(2 * math.pi * t / TIDE_PERIOD)) < 0.3:
        return "정조 (물 멈춤)"
    return "들물 ▲" if phase < 0.5 else "날물 ▼"


def bite_rate(rig, distance, chum, bait_level, tide=1.0):
    """초당 입질 확률."""
    total = 0.0
    for fid, pop in rig.spot.population.items():
        total += pop * preference(FISH_BY_ID[fid], rig)
    rate = 0.011 * total * distance_mult(distance, rig.spot) * rig.line["shy"]
    rate *= (1.0 + chum) * bait_level * tide
    return rate


def pick_fish(rig):
    ids = list(rig.spot.population)
    weights = [rig.spot.population[i] * preference(FISH_BY_ID[i], rig) for i in ids]
    if sum(weights) <= 0:
        return FISH_BY_ID[ids[0]]
    return FISH_BY_ID[random.choices(ids, weights)[0]]


def roll_size(fish, rig):
    """크기 비율 t(0~1), 길이 cm, 무게 g, 가격."""
    if rig.bait == "paste":
        a, b = [(1.3, 5.0), (1.7, 4.0), (2.3, 3.0)][rig.paste_size]
    elif rig.bait == "squid":
        a, b = 2.2, 3.1
    elif rig.bait == "shrimp":
        a, b = 1.9, 3.6
    elif rig.bait == "krill":
        a, b = 1.7, 4.0
    else:
        a, b = 1.6, 4.2
    t = random.betavariate(a + rig.spot.size_bonus, b)
    length = fish.min_len + t * (fish.max_len - fish.min_len)
    weight = fish.weight_coef * length ** 3
    price = int(fish.base_price * (0.35 + 1.9 * t ** 1.6) / 10) * 10
    return t, length, weight, max(10, price)


def hook_success(fish, rig):
    h = rig.hook["size"]
    if h > fish.mouth:
        return 0.55 if h - fish.mouth == 1 else 0.3
    return 0.93 if h == fish.mouth else 0.97


class BiteEvent:
    """찌의 움직임 시퀀스. 예신(깔짝)과 본신."""

    def __init__(self, fish, rig):
        self.fish = fish
        self.steps = []   # (kind, duration, amplitude)
        n = random.randint(0, 3) if fish.style != "quick" else random.randint(1, 4)
        for _ in range(n):
            self.steps.append(("wait", random.uniform(0.4, 1.4), 0))
            self.steps.append(("nibble", random.uniform(0.25, 0.4), random.uniform(0.15, 0.35)))
        self.steps.append(("wait", random.uniform(0.3, 1.2), 0))
        window = {"rise": 1.5, "sink": 1.1, "quick": 0.65}[fish.style]
        if rig.float_lying:
            window *= 0.6
        if rig.night:
            window *= 1.15 if rig.lantern else 0.75
        self.steps.append(("main", window, 1.0))
        self.index = 0
        self.timer = self.steps[0][1]

    @property
    def kind(self):
        return self.steps[self.index][0] if self.index < len(self.steps) else "done"

    @property
    def progress(self):
        if self.index >= len(self.steps):
            return 1.0
        dur = self.steps[self.index][1]
        return 1.0 - self.timer / dur

    def update(self, dt):
        """단계가 바뀌면 새 단계 이름을 돌려준다."""
        if self.index >= len(self.steps):
            return None
        self.timer -= dt
        if self.timer <= 0:
            self.index += 1
            if self.index < len(self.steps):
                self.timer = self.steps[self.index][1]
                return self.steps[self.index][0]
            return "done"
        return None

    def float_offset(self, lying):
        """찌 위치 오프셋: + 솟음, - 잠김."""
        k = self.kind
        amp = 0.35 if lying else 1.0
        p = self.progress
        if k == "nibble":
            return -math.sin(p * math.pi) * self.steps[self.index][2] * amp
        if k == "main":
            if self.fish.style == "rise":
                return min(1.0, p * 2.0) * 1.1 * amp
            if self.fish.style == "sink":
                return -min(1.0, p * 1.6) * 1.8 * amp
            return -min(1.0, p * 3.0) * 2.0 * amp
        return 0.0


class Fight:
    """물고기와의 힘겨루기."""

    def __init__(self, fish, t, length, weight, rig, distance):
        self.fish = fish
        self.t = t
        self.length = length
        self.weight = weight
        self.rig = rig
        self.distance = max(2.0, distance)
        self.max_line = max(45.0, self.distance + 25.0)
        self.strength = fish.strength[0] + (fish.strength[1] - fish.strength[0]) * t
        self.max_stamina = 13.0 * fish.stamina * (0.6 + 0.8 * t)
        self.stamina = self.max_stamina
        self.tension = 0.0
        self.running = False
        self.ramp = 0.0         # 차고 나갈 때 힘이 서서히 오른다
        self.run_timer = 0.0
        self.rest_timer = random.uniform(1.0, 2.0)
        self.x = 0.0            # 좌우 위치 -1 ~ 1
        self.target_x = random.uniform(-0.6, 0.6)
        self.slack_time = 0.0
        self.result = None      # None / snap / unhook / landed / spooled / net_miss
        self.jump = 0.0         # 점프 연출 타이머
        self.elapsed = 0.0

    @property
    def stamina_ratio(self):
        return max(0.0, self.stamina / self.max_stamina)

    @property
    def tension_ratio(self):
        return self.tension / self.rig.line["strength"]

    def update(self, dt, reeling, steer):
        if self.result:
            return
        self.elapsed += dt
        sr = self.stamina_ratio
        # 달리기(차고 나가기) 스케줄
        if self.running:
            self.run_timer -= dt
            if self.run_timer <= 0:
                self.running = False
                self.rest_timer = random.uniform(0.8, 2.5) * (1.6 - sr)
        else:
            self.rest_timer -= dt
            if self.rest_timer <= 0 and random.random() < 0.25 + 0.75 * sr:
                self.running = True
                self.run_timer = random.uniform(0.8, 2.4) * (0.4 + sr)
                self.target_x = random.uniform(-1, 1)
                if self.t > 0.5 and self.fish.depth != "bottom" and random.random() < 0.35:
                    self.jump = 0.8
            elif self.rest_timer <= 0:
                self.rest_timer = random.uniform(0.5, 1.5)

        self.ramp = min(1.0, self.ramp + dt / 0.6) if self.running else max(0.0, self.ramp - dt / 0.4)
        self.x += (self.target_x - self.x) * min(1.0, dt * (1.8 if self.running else 0.5))
        self.jump = max(0.0, self.jump - dt)

        pull = self.strength * (0.3 + 0.7 * self.ramp) * (0.35 + 0.65 * sr)
        run_speed = (1.2 + self.strength * 0.25) * (0.3 + 0.7 * sr)

        # 낚싯대를 물고기 반대쪽으로 기울이면 유리
        steer_ok = steer != 0 and (steer > 0) != (self.x > 0) and abs(self.x) > 0.15
        steer_bad = steer != 0 and not steer_ok and abs(self.x) > 0.15
        steer_f = 0.75 if steer_ok else (1.15 if steer_bad else 1.0)

        if reeling:
            raw = pull + 0.8 + self.strength * 0.15
            gain = (2.6 if self.rig.tip else 1.7) * (1.0 - 0.85 * min(1.0, pull / (self.strength + 0.3)))
            self.distance -= gain * dt
            if self.running:
                self.distance += run_speed * 0.35 * dt
        else:
            raw = pull * 0.5
            if self.running:
                self.distance += run_speed * dt
        target = raw * self.rig.rod["absorb"] * steer_f * min(1.0, 0.3 + self.elapsed * 0.7)
        self.tension += (target - self.tension) * min(1.0, dt * 3.5)

        drain = self.tension / max(0.4, self.strength) * (1.5 if steer_ok else 1.0)
        if self.running:
            drain += 0.4
        self.stamina -= drain * dt
        if self.tension < 0.2 * self.strength:
            self.stamina = min(self.max_stamina, self.stamina + 0.35 * dt)

        # 판정
        if self.tension > self.rig.line["strength"]:
            self.result = "snap"
            return
        if self.distance > self.max_line:
            self.result = "spooled"
            return
        slack_limit = 0.12 + 0.1 * self.strength
        if self.tension < slack_limit * self.rig.rod["absorb"] and not reeling:
            self.slack_time += dt
        else:
            self.slack_time = max(0.0, self.slack_time - dt * 2)
        if self.slack_time > 2.5 and random.random() < 0.6 * dt:
            self.result = "unhook"
            return
        hook = self.rig.hook["size"]
        if hook < self.fish.mouth and self.running and random.random() < 0.05 * (self.fish.mouth - hook) * dt:
            self.result = "unhook"
            return
        if self.jump > 0 and self.tension_ratio > 0.7 and random.random() < 0.3 * dt:
            self.result = "unhook"
            return
        if self.distance <= 0.6:
            if self.length >= 45 and not self.rig.net and random.random() < 0.45:
                self.result = "net_miss"
            else:
                self.result = "landed"
