"""효과음 / 환경음: 코드로 합성하거나, tools/make_sfx.py 로 미리 만든 OGG 를 읽는다."""
import math
import os
import random
from array import array

import pygame

from .settings import resource_path

RATE = 22050
CHANNELS = 1


def _to_sound(samples, volume=1.0):
    """합성한 샘플을 믹서 포맷(16bit)에 맞춰 Sound 로 만든다."""
    vals = [max(-32767, min(32767, int(s * 32767 * volume))) for s in samples]
    if CHANNELS > 1:
        vals = [v for v in vals for _ in range(CHANNELS)]
    return pygame.mixer.Sound(buffer=array("h", vals).tobytes())


def _env(i, n, attack=0.01, release=0.3):
    t = i / n
    a = min(1.0, t / attack) if attack > 0 else 1.0
    r = min(1.0, (1 - t) / release) if release > 0 else 1.0
    return a * r


def _noise(dur, lowpass=0.3, decay=6.0):
    n = int(RATE * dur)
    out, prev = [], 0.0
    for i in range(n):
        prev += (random.uniform(-1, 1) - prev) * lowpass
        out.append(prev * math.exp(-decay * i / n))
    return out


def _tone(freq_fn, dur, wave="sine", attack=0.01, release=0.4):
    n = int(RATE * dur)
    out, phase = [], 0.0
    for i in range(n):
        f = freq_fn(i / n)
        phase += 2 * math.pi * f / RATE
        if wave == "square":
            v = 1.0 if math.sin(phase) > 0 else -1.0
            v *= 0.4
        elif wave == "tri":
            v = 2 / math.pi * math.asin(math.sin(phase))
        else:
            v = math.sin(phase)
        out.append(v * _env(i, n, attack, release))
    return out


def _mix(*tracks):
    n = max(len(t) for t in tracks)
    out = [0.0] * n
    for t in tracks:
        for i, v in enumerate(t):
            out[i] += v
    return out


def _concat(*tracks):
    out = []
    for t in tracks:
        out.extend(t)
    return out


def _silence(dur):
    return [0.0] * int(RATE * dur)


def definitions():
    """효과음 이름 -> (샘플 목록, 볼륨)."""
    s = {}
    s["cast"] = (_tone(lambda t: 900 - 600 * t, 0.25, attack=0.05, release=0.5), 0.25)
    s["splash"] = (_noise(0.35, 0.25, 7), 0.55)
    s["plop"] = (_tone(lambda t: 500 - 300 * t, 0.12, release=0.6), 0.35)
    s["nibble"] = (_tone(lambda t: 700 - 200 * t, 0.06, release=0.6), 0.18)
    s["hook"] = (_mix(_noise(0.2, 0.6, 3), _tone(lambda t: 300 + 700 * t, 0.2)), 0.35)
    s["reel"] = (_mix(_noise(0.03, 0.9, 10), _tone(lambda t: 2200, 0.03, "square")), 0.18)
    s["snap"] = (_mix(_noise(0.15, 0.95, 12), _tone(lambda t: 1800 - 1500 * t, 0.25, "square")), 0.4)
    s["escape"] = (_tone(lambda t: 500 - 300 * t, 0.5, "tri"), 0.35)
    s["jump"] = (_noise(0.5, 0.35, 5), 0.5)
    notes = [523, 659, 784, 1046]
    s["catch"] = (_concat(*[_tone(lambda t, f=f: f, 0.12, "tri", release=0.5) for f in notes],
                                   _tone(lambda t: 1046, 0.35, "tri")), 0.4)
    s["record"] = (_concat(*[_tone(lambda t, f=f: f, 0.1, "square") for f in (784, 988, 1175, 1568)],
                                    _tone(lambda t: 1568, 0.4, "square")), 0.25)
    s["coin"] = (_concat(_tone(lambda t: 988, 0.07, "square"), _tone(lambda t: 1319, 0.25, "square")), 0.25)
    s["click"] = (_tone(lambda t: 1200, 0.03, release=0.8), 0.25)
    s["error"] = (_tone(lambda t: 180, 0.2, "square"), 0.25)
    s["bird"] = (_concat(_tone(lambda t: 3000 + 1500 * math.sin(t * 9), 0.18, release=0.3),
                                  _silence(0.08),
                                  _tone(lambda t: 3400 - 900 * t, 0.12)), 0.12)
    cricket = []
    for _ in range(6):
        cricket += _tone(lambda t: 4200, 0.035, attack=0.2, release=0.4) + _silence(0.03)
    s["cricket"] = (cricket, 0.08)
    wave = _noise(1.8, 0.08, 0.0)
    n = len(wave)
    s["wave"] = ([v * math.sin(math.pi * i / n) ** 2 for i, v in enumerate(wave)], 0.5)
    s["gull"] = (_concat(_tone(lambda t: 1500 + 700 * (1 - t), 0.22, "tri", release=0.3), _silence(0.05),
                                  _tone(lambda t: 1400 + 600 * (1 - t), 0.3, "tri", release=0.4)), 0.12)
    s["frog"] = (_tone(lambda t: 180 + 60 * math.sin(t * 40), 0.25, "square"), 0.1)
    return s


SOUND_NAMES = ["cast", "splash", "plop", "nibble", "hook", "reel", "snap", "escape", "jump", "catch", "record",
               "coin", "click", "error", "bird", "cricket", "wave", "gull", "frog"]


class Sounds:
    def __init__(self, settings):
        self.settings = settings
        self.ok = False
        self.sounds = {}
        self.ambient_timer = 3.0
        try:
            global RATE, CHANNELS
            if not pygame.mixer.get_init():
                pygame.mixer.init(RATE, -16, 1, 512)
            freq, fmt, channels = pygame.mixer.get_init()
            RATE, CHANNELS = freq, channels
            self._build()
            self.ok = True
        except pygame.error:
            self.ok = False

    def _build(self):
        folder = resource_path("assets", "sfx")
        files = {name: os.path.join(folder, name + ".ogg") for name in SOUND_NAMES}
        if all(os.path.exists(p) for p in files.values()):
            # 미리 만들어 둔 OGG (웹 버전은 파이썬 합성이 느려서 이쪽을 쓴다)
            self.sounds = {name: pygame.mixer.Sound(p) for name, p in files.items()}
        else:
            self.sounds = {name: _to_sound(*v) for name, v in definitions().items()}

    def play(self, name):
        if not self.ok or not self.settings["sfx"]:
            return
        snd = self.sounds.get(name)
        if snd:
            snd.set_volume(self.settings["volume"])
            snd.play()

    def update_ambient(self, dt, night, sea=False):
        if not self.ok or not self.settings["ambient"]:
            return
        self.ambient_timer -= dt
        if self.ambient_timer <= 0:
            self.ambient_timer = random.uniform(3, 9)
            if sea:
                self.ambient_timer = random.uniform(2, 5)
                name = "wave" if night or random.random() < 0.7 else "gull"
            else:
                name = random.choice(["cricket", "cricket", "frog"]) if night else "bird"
            snd = self.sounds[name]
            snd.set_volume(self.settings["volume"])
            snd.play()
