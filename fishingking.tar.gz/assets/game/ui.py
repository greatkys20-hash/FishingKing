"""폰트, 나무판 스타일 버튼/패널 등 UI 도우미."""
import os

import pygame

from .settings import (FONT_BOLD_CANDIDATES, FONT_CANDIDATES, FONT_SCALE, WOOD, WOOD_DARK, WOOD_DISABLED,
                       WOOD_LIGHT, WOOD_TEXT)

_font_cache = {}


def _find_font(candidates):
    for path in candidates:
        if os.path.exists(path):
            return path
    return None


def font(size, bold=False):
    size = max(8, round(size * FONT_SCALE))
    key = (size, bold)
    if key not in _font_cache:
        path = _find_font(FONT_BOLD_CANDIDATES if bold else FONT_CANDIDATES)
        if path:
            _font_cache[key] = pygame.font.Font(path, size)
        else:
            _font_cache[key] = pygame.font.SysFont("malgungothic,applegothic,nanumgothic,gulim", size, bold)
    return _font_cache[key]


_text_cache = {}


def render(msg, size, color, bold=False):
    """글자 렌더링 캐시 (매 프레임 같은 글자를 다시 그리지 않도록)."""
    key = (msg, size, color, bold)
    img = _text_cache.get(key)
    if img is None:
        if len(_text_cache) > 600:
            _text_cache.clear()
        img = font(size, bold).render(msg, True, color)
        _text_cache[key] = img
    return img


def text(surface, msg, pos, size=18, color=WOOD_TEXT, bold=False, center=False, shadow=None, right=False):
    msg = str(msg)
    color = tuple(color)
    img = render(msg, size, color, bold)
    rect = img.get_rect()
    if center:
        rect.center = pos
    elif right:
        rect.topright = pos
    else:
        rect.topleft = pos
    if shadow:
        sh = render(msg, size, tuple(shadow), bold)
        surface.blit(sh, rect.move(2, 2))
    surface.blit(img, rect)
    return rect


def wrap_text(msg, size, width, bold=False):
    f = font(size, bold)
    lines, line = [], ""
    for ch in msg:
        if ch == "\n":
            lines.append(line)
            line = ""
            continue
        if f.size(line + ch)[0] > width:
            cut = line.rfind(" ")
            if cut > 0:
                lines.append(line[:cut])
                line = line[cut + 1:] + ch
            else:
                lines.append(line)
                line = ch
        else:
            line += ch
    if line:
        lines.append(line)
    return lines


def wood_panel(surface, rect, color=WOOD, screws=True, border=3):
    rect = pygame.Rect(rect)
    pygame.draw.rect(surface, WOOD_DARK, rect.move(3, 4), border_radius=4)
    pygame.draw.rect(surface, color, rect, border_radius=4)
    # 나뭇결
    grain = tuple(max(0, c - 14) for c in color)
    for y in range(rect.top + 7, rect.bottom - 4, 9):
        pygame.draw.line(surface, grain, (rect.left + 6, y), (rect.right - 6, y + ((y * 7) % 3) - 1), 1)
    light = tuple(min(255, c + 25) for c in color)
    pygame.draw.line(surface, light, (rect.left + 2, rect.top + 2), (rect.right - 3, rect.top + 2), 2)
    pygame.draw.rect(surface, WOOD_DARK, rect, border, border_radius=4)
    if screws and rect.w > 40 and rect.h > 26:
        for sx, sy in ((rect.left + 7, rect.top + 7), (rect.right - 8, rect.top + 7),
                       (rect.left + 7, rect.bottom - 8), (rect.right - 8, rect.bottom - 8)):
            pygame.draw.circle(surface, (120, 100, 70), (sx, sy), 3)
            pygame.draw.circle(surface, (200, 190, 170), (sx - 1, sy - 1), 1)


class Button:
    def __init__(self, rect, label, callback=None, size=20, enabled=True, toggled=False, bold=True, tag=None):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.callback = callback
        self.size = size
        self.enabled = enabled
        self.toggled = toggled
        self.bold = bold
        self.hover = False
        self.tag = tag

    def draw(self, surface):
        if not self.enabled:
            color = WOOD_DISABLED
        elif self.toggled:
            color = (246, 222, 150)
        elif self.hover:
            color = WOOD_LIGHT
        else:
            color = WOOD
        wood_panel(surface, self.rect, color, screws=self.rect.h >= 40)
        tc = (120, 100, 70) if not self.enabled else WOOD_TEXT
        text(surface, self.label, self.rect.center, self.size, tc, bold=self.bold, center=True)
        if self.toggled:
            pygame.draw.rect(surface, (180, 60, 30), self.rect.inflate(-6, -6), 2, border_radius=3)

    def handle(self, event, sounds=None):
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.enabled and self.callback:
                    if sounds:
                        sounds.play("click")
                    self.callback()
                elif not self.enabled and sounds:
                    sounds.play("error")
                return True
        return False


class Slider:
    """ - [====|====] + 형태의 조절 막대."""

    def __init__(self, rect, label, value, vmin, vmax, step, on_change, fmt="{:.0f}"):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.value = value
        self.vmin, self.vmax, self.step = vmin, vmax, step
        self.on_change = on_change
        self.fmt = fmt
        self.dragging = False
        r = self.rect
        self.minus = pygame.Rect(r.left, r.top, 26, 26)
        self.plus = pygame.Rect(r.right - 26, r.top, 26, 26)
        self.bar = pygame.Rect(r.left + 4, r.top + 30, r.w - 8, 20)

    def _set(self, v):
        v = round(round((v - self.vmin) / self.step) * self.step + self.vmin, 4)
        v = max(self.vmin, min(self.vmax, v))
        if v != self.value:
            self.value = v
            self.on_change(v)

    def draw(self, surface):
        wood_panel(surface, self.rect.inflate(6, 6), screws=False, border=2)
        text(surface, "-", self.minus.center, 22, bold=True, center=True)
        text(surface, "+", self.plus.center, 22, bold=True, center=True)
        text(surface, f"{self.label} {self.fmt.format(self.value)}", (self.rect.centerx, self.rect.top + 13),
             18, bold=True, center=True)
        pygame.draw.rect(surface, (90, 90, 50), self.bar)
        pygame.draw.rect(surface, (60, 50, 30), self.bar, 2)
        t = (self.value - self.vmin) / (self.vmax - self.vmin)
        knob_x = self.bar.left + 4 + t * (self.bar.w - 8)
        pygame.draw.rect(surface, (200, 200, 190), (knob_x - 4, self.bar.top + 2, 8, self.bar.h - 4))

    def handle(self, event, sounds=None):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.minus.collidepoint(event.pos):
                self._set(self.value - self.step)
                if sounds:
                    sounds.play("click")
                return True
            if self.plus.collidepoint(event.pos):
                self._set(self.value + self.step)
                if sounds:
                    sounds.play("click")
                return True
            if self.bar.inflate(0, 10).collidepoint(event.pos):
                self.dragging = True
                self._drag(event.pos[0])
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self._drag(event.pos[0])
            return True
        return False

    def _drag(self, x):
        t = (x - self.bar.left - 4) / max(1, self.bar.w - 8)
        self._set(self.vmin + max(0.0, min(1.0, t)) * (self.vmax - self.vmin))
