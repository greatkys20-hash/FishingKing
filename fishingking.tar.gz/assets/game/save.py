"""세이브 데이터."""
import json
import os

from .settings import IS_WEB, SAVE_FILE

STORAGE_KEY = "FishingKing.save"


def _local_storage():
    """브라우저(pygbag)의 localStorage."""
    import platform
    return platform.window.localStorage

DEFAULT = {
    "money": 1000,
    "rod": "rod0",
    "line": "line0",
    "hook": "hook2",
    "owned": ["rod0", "line0", "hook2"],
    "stock": {"paste": 20, "worm": 10, "shrimp": 0, "krill": 0, "clamworm": 0, "squid": 0},
    "bait": "paste",        # 민물 미끼
    "sea_bait": "krill",    # 바다 미끼
    "paste_size": 1,
    "mix": [4, 4, 4],
    "depths": {},           # spot key -> 찌 높이(채비 수심) m
    "unlocked": ["river"],
    "spot": "B",
    "night": False,
    "book": {},             # fish_id -> {"count": n, "max": cm, "max_w": g}
    "total_catch": 0,
    "total_earned": 0,
    "biggest": None,        # {"fish": id, "len": cm}
    "sound": {"sfx": True, "ambient": True, "volume": 0.7},
    "tutorial": False,
    "king": False,
}


class SaveData:
    def __init__(self):
        self.data = json.loads(json.dumps(DEFAULT))

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value

    @staticmethod
    def exists():
        if IS_WEB:
            try:
                return _local_storage().getItem(STORAGE_KEY) is not None
            except Exception:
                return False
        return os.path.exists(SAVE_FILE)

    def _read(self):
        if IS_WEB:
            raw = _local_storage().getItem(STORAGE_KEY)
            if raw is None:
                raise OSError("no save")
            return json.loads(str(raw))
        with open(SAVE_FILE, encoding="utf-8") as f:
            return json.load(f)

    def load(self):
        try:
            loaded = self._read()
        except Exception:
            return False
        for k, v in loaded.items():
            if k in self.data:
                if isinstance(self.data[k], dict) and isinstance(v, dict) and k != "book":
                    self.data[k].update(v)
                else:
                    self.data[k] = v
        return True

    def save(self):
        if IS_WEB:
            try:
                _local_storage().setItem(STORAGE_KEY, json.dumps(self.data, ensure_ascii=False))
            except Exception:
                pass
            return
        tmp = SAVE_FILE + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=1)
            os.replace(tmp, SAVE_FILE)
        except OSError:
            pass

    def bait_for(self, spot):
        return self.data["sea_bait"] if spot.sea else self.data["bait"]

    def set_bait(self, spot, key):
        self.data["sea_bait" if spot.sea else "bait"] = key

    def depth_for(self, spot):
        return self.data["depths"].get(spot.key, spot.bottom)

    def set_depth(self, spot, value):
        self.data["depths"][spot.key] = round(value, 1)

    def owns(self, item_id):
        return item_id in self.data["owned"]

    def record_catch(self, fish, length, weight):
        """도감 기록. 신기록이면 True."""
        book = self.data["book"]
        entry = book.setdefault(fish.id, {"count": 0, "max": 0, "max_w": 0})
        entry["count"] += 1
        new_record = length > entry["max"]
        if new_record:
            entry["max"] = round(length, 1)
            entry["max_w"] = int(weight)
        self.data["total_catch"] += 1
        big = self.data["biggest"]
        if big is None or weight > big.get("w", 0):
            self.data["biggest"] = {"fish": fish.id, "len": round(length, 1), "w": int(weight)}
        return new_record
