"""게임 루프와 공용 리소스."""
import asyncio

import pygame

from . import gfx
from .save import SaveData
from .settings import FPS, IS_WEB, SCREEN_H, SCREEN_W, TITLE
from .sfx import Sounds


def make_icon():
    from .data import FISH_BY_ID
    icon = pygame.Surface((64, 64), pygame.SRCALPHA)
    pygame.draw.circle(icon, (60, 130, 190), (32, 32), 31)
    gfx.draw_fish(icon, FISH_BY_ID["golden_carp"], (32, 34), 52)
    return icon


class App:
    def __init__(self):
        if not IS_WEB:
            pygame.mixer.pre_init(22050, -16, 1, 512)
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_icon(make_icon())
        self.clock = pygame.time.Clock()
        self.save = SaveData()
        self.save.load()
        self.sounds = Sounds(self.save["sound"])
        self.running = True
        self._bg_cache = {}
        self._map_cache = {}
        from .scenes import TitleScene
        self.scene = TitleScene(self)

    def background(self, spot, night):
        key = (spot.key, night)
        if key not in self._bg_cache:
            self._bg_cache[key] = gfx.build_background(spot, night)
        return self._bg_cache[key]

    def map_surface(self, region, night):
        key = (region, night)
        if key not in self._map_cache:
            self._map_cache[key] = gfx.region_map(region, night)
        return self._map_cache[key]

    def change(self, scene):
        self.scene = scene

    def is_portrait(self):
        """모바일 브라우저에서 세로 화면인지."""
        if not IS_WEB:
            return False
        try:
            import platform
            return platform.window.innerHeight > platform.window.innerWidth
        except Exception:
            return False

    def draw_rotate_hint(self):
        from .ui import text
        self.screen.fill((20, 40, 60))
        cx, cy = SCREEN_W // 2, SCREEN_H // 2
        pygame.draw.rect(self.screen, (230, 230, 230), (cx - 45, cy - 150, 90, 150), 6, border_radius=12)
        pygame.draw.rect(self.screen, (255, 205, 60), (cx - 20, cy + 30, 150, 90), 6, border_radius=12)
        pygame.draw.arc(self.screen, (255, 205, 60), (cx - 110, cy - 110, 160, 160), 3.6, 5.2, 5)
        text(self.screen, "휴대폰을 가로로 돌려주세요", (cx, cy + 180), 40, (255, 255, 255), bold=True, center=True)

    async def run(self):
        portrait_check = 0.0
        portrait = False
        while self.running:
            dt = min(0.05, self.clock.tick(FPS) / 1000.0)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif not portrait:
                    self.scene.handle(event)
            portrait_check -= dt
            if portrait_check <= 0:
                portrait_check = 0.5
                portrait = self.is_portrait()
                if IS_WEB:
                    try:
                        import platform
                        platform.window.fk_fps = round(self.clock.get_fps(), 1)   # 성능 확인용
                    except Exception:
                        pass
            if portrait:
                self.draw_rotate_hint()
            else:
                self.scene.update(dt)
                self.scene.draw(self.screen)
            pygame.display.flip()
            await asyncio.sleep(0)      # 브라우저에 제어를 넘겨준다 (pygbag 필수)
        self.save.save()
        if not IS_WEB:
            pygame.quit()
